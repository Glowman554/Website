set -e

bash prepare.sh

rm /tmp/run.ys || true

for file in core/*.v modules/*.v; do
    if [[ -f "$file" ]]; then
        echo "read_verilog $file" >> /tmp/run.ys
    fi
done

# maybe take a look at synth_gowin? might work better??

echo "hierarchy -top Inferno" >> /tmp/run.ysp
# echo "synth_gowin" >> /tmp/run.ys
echo "proc; opt; techmap; opt;" >> /tmp/run.ys
echo "write_verilog synth.v" >> /tmp/run.ys
# echo "show -format ps -viewer gv" >> /tmp/run.ys

yosys -s /tmp/run.ys
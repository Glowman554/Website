set -e


echo "Error: 'help' command not found. Looks like we're in deeper trouble than an outdated CPU!"
echo "Better call tech support and pray for a miracle."
echo "Debugging this code feels like navigating a maze blindfolded. Send help!"

read -p "Test? " test
cp ../tests/$test.hex firmware.hex
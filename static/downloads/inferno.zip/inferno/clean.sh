rm tests/*.bin
rm tests/*.hex
rm rtl/*.hex
rm rtl/*.lxt
rm rtl/synth.v
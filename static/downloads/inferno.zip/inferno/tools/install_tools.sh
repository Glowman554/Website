git clone https://github.com/hlorenzi/customasm || true
(
	cd customasm
	cp ../platform.asm std/cpu/inferno.asm
	cargo build
    sudo cp target/debug/customasm /usr/bin/inferno-as
)
gcc b2h.c -o b2h
sudo cp b2h /usr/bin/inferno-b2h

rm -rf customasm b2h
package de.glowman554.javaidle;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class ValueSaver
{
	public static double load(File f)
	{
		if (f.exists())
		{
			try
			{
				return Double.parseDouble(Files.readString(f.toPath()));
			}
			catch (NumberFormatException | IOException e)
			{
				e.printStackTrace();
			}
		}

		return 0;
	}

	public static void save(File f, double val)
	{

		try
		{
			Files.writeString(f.toPath(), String.valueOf(val));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}

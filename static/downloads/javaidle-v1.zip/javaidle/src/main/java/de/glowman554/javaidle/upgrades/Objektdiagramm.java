package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Objektdiagramm extends AbstractUpgrade
{

	public Objektdiagramm(int y, InGame inGame)
	{
		super(y, inGame, 10000, 1000);
	}

	@Override
	public String getName()
	{
		return "Objektdiagramm";
	}

}

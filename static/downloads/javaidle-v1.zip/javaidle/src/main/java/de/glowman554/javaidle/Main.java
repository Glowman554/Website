package de.glowman554.javaidle;

import de.glowman554.renderfox.RenderFoxBuilder;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.SplashScreen;

public class Main
{
	public static void main(String[] args)
	{
		new RenderFoxBuilder()
		.targetFPS(60)
		.size(640, 640 + 320)
		.title("Java Idle")
		.launch(new SplashScreen(new LazyTexture("splash.png"), new TitleScreen(), 1000));
	}
}

package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Datenkapselung extends AbstractUpgrade
{

	public Datenkapselung(int y, InGame game)
	{
		super(y, game, 10, 1);
	}

	@Override
	public String getName()
	{
		return "Datenkapselung";
	}


}

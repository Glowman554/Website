package de.glowman554.javaidle;

import java.io.File;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.javaidle.upgrades.AbstractUpgrade;
import de.glowman554.javaidle.upgrades.Datenkapselung;
import de.glowman554.javaidle.upgrades.HelloWorld;
import de.glowman554.javaidle.upgrades.Klassendiagram;
import de.glowman554.javaidle.upgrades.Objektdiagramm;
import de.glowman554.javaidle.upgrades.Polymorphie;
import de.glowman554.javaidle.upgrades.SchichtenArchitektur;
import de.glowman554.javaidle.upgrades.Scrum;
import de.glowman554.javaidle.upgrades.Zustandsdiagramm;
import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.AnimatedSprite;
import de.glowman554.renderfox.rendering.RenderResourceDisposeEvent;
import de.glowman554.renderfox.rendering.ui.TextureButton;
import de.glowman554.renderfox.timer.Timer;
import de.glowman554.renderfox.utils.Point2D;

public class InGame extends GameScene
{
	private LazyTexture logo;
	private TextureButton logoButton;
	private LazyTexture rewrite;
	private TextureButton rewriteButton;

	private LazyTexture[] money_animation = new LazyTexture[] {new LazyTexture("money_0.png"), new LazyTexture("money_1.png")};

	private AnimatedSprite money_1;
	private AnimatedSprite money_2;

	private GlyphLayout layout;

	public double money = 0;
	private double knowledge = 1;
	public float lastMoneyPerTick = 0;

	private AbstractUpgrade[] upgrades;

	private LazySound cashMoney;
	private LazySound rewriteSound;

	@Override
	public void init() throws Exception
	{
		logo = new LazyTexture("logo.png");

		int x = Gdx.graphics.getWidth() / 2 - logo.getTexture().getWidth() / 2;
		int y = Gdx.graphics.getHeight() - logo.getTexture().getHeight();

		logoButton = new TextureButton(new Point2D(x, y), logo, () -> {
			money += 1 * knowledge;
			cashMoney.getSound().play();
		});

		rewrite = new LazyTexture("rewrite.png");

		int x2 = Gdx.graphics.getWidth() / 2 - rewrite.getTexture().getWidth() / 2;

		rewriteButton = new TextureButton(new Point2D(x2, 0), rewrite, () -> {
			for (var u : upgrades)
			{
				if (u.getLevel() == 0)
				{
					return;
				}
			}
			rewriteSound.getSound().play();

			double k = 0;
			for (var u : upgrades)
			{
				k += u.getLevel();
				u.setLevel(0);
			}

			knowledge += k / upgrades.length;
			money = 0;
		});

		int y2 = Gdx.graphics.getHeight() - logo.getTexture().getHeight() + money_animation[0].getTexture().getHeight() / 2;

		money_1 = new AnimatedSprite(money_animation, 10, new Point2D(30, y2));
		money_2 = new AnimatedSprite(money_animation, 10, new Point2D(Gdx.graphics.getWidth() - money_animation[0].getTexture().getWidth() - 30, y2));

		layout = new GlyphLayout();

		int i = 2;
		upgrades = new AbstractUpgrade[] {new HelloWorld(y - (32 * i++), this), new Datenkapselung(y - (32 * i++), this), new Klassendiagram(y - (32 * i++), this), new SchichtenArchitektur(y - (32 * i++), this), new Polymorphie(y - (32 * i++), this), new Objektdiagramm(y - (32 * i++), this), new Zustandsdiagramm(y - (32 * i++), this), new Scrum(y - (32 * i++), this)};

		cashMoney = new LazySound("sounds/cash_money.mp3");
		rewriteSound = new LazySound("sounds/rewrite.mp3");

		load();

		Timer.repeatEvery(() -> {
			float moneyPerTick = 0;
			for (var u : upgrades)
			{
				moneyPerTick += u.getTickMoney(knowledge);
			}
			lastMoneyPerTick = moneyPerTick;
			money += moneyPerTick;
		}, 1000);
	}

	@Override
	public void update(RenderFox renderFox)
	{
		money_1.tick();
		money_2.tick();
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0.3f, 0.3f, 1f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		batch.begin();
		logoButton.render(font);
		renderRewrite(font);
		money_1.render(font);
		money_2.render(font);

		String money_string = String.format("%.2f$ (%.2f$ / S)", money, lastMoneyPerTick);

		layout.setText(font, money_string);
		int mx = Gdx.graphics.getWidth() / 2 - (int) layout.width / 2;

		font.draw(batch, layout, mx, logoButton.getLocation().getY());

		for (var u : upgrades)
		{
			u.render(font);
		}

		batch.end();
	}

	public void renderRewrite(BitmapFont font)
	{
		for (var u : upgrades)
		{
			if (u.getLevel() == 0)
			{
				return;
			}
		}

		rewriteButton.render(font);
	}

	@EventTarget
	public void onDispose(RenderResourceDisposeEvent e)
	{
		save();
	}

	public void load()
	{
		money = ValueSaver.load(new File("money.save"));
		knowledge = ValueSaver.load(new File("knowledge.save"));
		if (knowledge == 0)
		{
			knowledge = 1;
		}
	}

	public void save()
	{
		ValueSaver.save(new File("money.save"), money);
		ValueSaver.save(new File("knowledge.save"), knowledge);
	}
}

package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Klassendiagram extends AbstractUpgrade
{

	public Klassendiagram(int y, InGame inGame)
	{
		super(y, inGame, 100, 10);
	}

	@Override
	public String getName()
	{
		return "Klassendiagram";
	}



}

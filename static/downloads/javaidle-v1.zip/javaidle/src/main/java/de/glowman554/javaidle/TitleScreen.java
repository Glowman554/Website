package de.glowman554.javaidle;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.logging.Logger;
import de.glowman554.renderfox.rendering.ui.TextureButton;
import de.glowman554.renderfox.utils.Point2D;

public class TitleScreen extends GameScene
{
	private LazyTexture logo;
	private TextureButton start;

	private boolean transition = false;

	@Override
	public void init() throws Exception
	{
		logo = new LazyTexture("logo.png");

		LazyTexture startTexture = new LazyTexture("start_button.png");

		int x = Gdx.graphics.getWidth() / 2 - startTexture.getTexture().getWidth() / 2;
		int y = (Gdx.graphics.getHeight() / 2 - logo.getTexture().getHeight() / 2) - startTexture.getTexture().getHeight();

		start = new TextureButton(new Point2D(x, y), startTexture, () -> {
			transition = true;
		});
		
		new Thread(() -> {
			new LazySound("sounds/speedrun.mp3").getSound().loop((float) .1);
			Logger.log("Started background music");

		}).start();
	}

	@Override
	public void update(RenderFox renderFox)
	{
		if (transition)
		{
			renderFox.transition(new InGame());
		}
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0.3f, 0.3f, 1f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		int x = Gdx.graphics.getWidth() / 2 - logo.getTexture().getWidth() / 2;
		int y = Gdx.graphics.getHeight() / 2 - logo.getTexture().getHeight() / 2;

		batch.begin();
		batch.draw(logo.getTexture(), x, y);
		start.render(font);
		batch.end();
	}

}

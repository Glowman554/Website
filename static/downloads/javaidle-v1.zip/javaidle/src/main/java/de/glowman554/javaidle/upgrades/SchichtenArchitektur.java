package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class SchichtenArchitektur extends AbstractUpgrade
{

	public SchichtenArchitektur(int y, InGame inGame)
	{
		super(y, inGame, 1000, 100);
	}

	@Override
	public String getName()
	{
		return "Schichten-Architektur";
	}

}

package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Zustandsdiagramm extends AbstractUpgrade
{

	public Zustandsdiagramm(int y, InGame inGame)
	{
		super(y, inGame, 50000, 5000);
	}

	@Override
	public String getName()
	{
		return "Zustandsdiagramm";
	}

}

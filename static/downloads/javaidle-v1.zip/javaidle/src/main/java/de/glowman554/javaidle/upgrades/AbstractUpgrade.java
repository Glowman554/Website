package de.glowman554.javaidle.upgrades;

import java.io.File;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.javaidle.InGame;
import de.glowman554.javaidle.ValueSaver;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderComponent;
import de.glowman554.renderfox.rendering.ui.TextureButton;
import de.glowman554.renderfox.utils.Point2D;

public abstract class AbstractUpgrade extends RenderComponent
{
	protected int level = 0;
	protected InGame inGame;
	private int y = 0;

	private LazySound takeMyMoney;

	private LazyTexture buy = new LazyTexture("buy.png");
	private TextureButton buyButton;

	private double basePrice;
	private double baseTickMoney;

	public AbstractUpgrade(int y, InGame inGame, double basePrice, double baseTickMoney)
	{
		this.y = y;
		this.basePrice = basePrice;
		this.baseTickMoney = baseTickMoney;
		buyButton = new TextureButton(new Point2D(Gdx.graphics.getWidth() - buy.getTexture().getWidth(), y - 32), buy, () -> {
			if (inGame.money >= getPrice())
			{
				inGame.money -= getPrice();
				level++;
				save();
				takeMyMoney.getSound().play();
			}
		});
		this.inGame = inGame;

		takeMyMoney = new LazySound("sounds/take_my_money.mp3");

		load();

	}

	public double getPrice()
	{
		return Math.pow(basePrice * (level + 1), 1.1);
	}

	public abstract String getName();

	public double getTickMoney(double knowledge)
	{
		return (baseTickMoney * level) * knowledge;
	}

	public int getLevel()
	{
		return level;
	}

	public void setLevel(int level)
	{
		this.level = level;
		save();
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();
		font.draw(batch, String.format("%s (%d): %.2f", getName(), getLevel(), getPrice()), 10, y);
		if (inGame.money >= getPrice())
		{
			buyButton.render(font);
		}
		batch.end();
	}

	public void load()
	{
		File folder = new File("upgrades");

		level = (int) ValueSaver.load(new File(folder, getClass().getSimpleName() + ".save"));
	}

	public void save()
	{
		File folder = new File("upgrades");
		folder.mkdir();

		ValueSaver.save(new File(folder, getClass().getSimpleName() + ".save"), (double) level);
	}
}

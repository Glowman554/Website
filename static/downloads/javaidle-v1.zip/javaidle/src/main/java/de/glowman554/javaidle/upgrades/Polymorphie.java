package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Polymorphie extends AbstractUpgrade
{

	public Polymorphie(int y, InGame inGame)
	{
		super(y, inGame, 5000, 500);
	}

	@Override
	public String getName()
	{
		return "Polymorphie";
	}

}

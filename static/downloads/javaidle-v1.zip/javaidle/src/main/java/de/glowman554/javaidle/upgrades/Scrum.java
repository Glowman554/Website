package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class Scrum extends AbstractUpgrade
{

	public Scrum(int y, InGame inGame)
	{
		super(y, inGame, 100000, 10000);
	}

	@Override
	public String getName()
	{
		return "Scrum";
	}

}

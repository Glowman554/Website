package de.glowman554.javaidle.upgrades;

import de.glowman554.javaidle.InGame;

public class HelloWorld extends AbstractUpgrade
{

	public HelloWorld(int y, InGame inGame)
	{
		super(y, inGame, 0.1, 0.01);
	}

	@Override
	public String getName()
	{
		return "Hello World";
	}

}

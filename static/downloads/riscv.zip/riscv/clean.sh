rm tests/*.hex*
rm rtl/*.hex
rm rtl/*.lxt
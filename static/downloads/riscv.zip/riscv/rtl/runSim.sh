set -ex

bash prepare.sh

iverilog -o /tmp/run sim/*.v core/*.v modules/*.v
vvp /tmp/run -lxt2
#gtkwave test.gtkw
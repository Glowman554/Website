(
    git clone https://github.com/sifive/elf2hex
    cd elf2hex
    autoreconf -i
    ./configure --target=riscv64-unknown-elf
    make
    make install
)
rm -rf elf2hex
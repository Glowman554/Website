def genMux(channels, bitWidth):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    inputs = alphabet[:channels]
    bitsNeeded = len("{0:b}".format(len(inputs) - 1))

    verilog_code = ""
    
    verilog_code += f"module mux{bitWidth}_{channels} (\n"
    verilog_code += f"\tinput [{bitWidth - 1}:0] {', '.join([i for i in inputs])},\n"
    verilog_code += f"\tinput [{bitsNeeded - 1}:0] sel,\n"
    verilog_code += f"\toutput reg [{bitWidth-1}:0] out\n"
    verilog_code += f");\n"
    verilog_code += f"\talways @(*) begin\n"
    verilog_code += f"\t\tcase (sel)\n"
    for i in range(channels):
        verilog_code += f"\t\t\t{bitsNeeded}'d{i}: out <= {inputs[i]};\n"
    verilog_code += "\t\tendcase\n"
    verilog_code += "\tend\n"
    verilog_code += "endmodule\n"

    return verilog_code

def genDemux(channels, bitWidth):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    outputs = alphabet[:channels]
    bitsNeeded = len("{0:b}".format(len(outputs) - 1))

    verilog_code = ""
    
    verilog_code += f"module demux{bitWidth}_{channels} (\n"
    verilog_code += f"\toutput reg [{bitWidth - 1}:0] {', '.join([i for i in outputs])},\n"
    verilog_code += f"\tinput [{bitsNeeded - 1}:0] sel,\n"
    verilog_code += f"\tinput [{bitWidth-1}:0] in\n"
    verilog_code += f");\n"
    verilog_code += f"\talways @(*) begin\n"
    verilog_code += f"\t\tcase (sel)\n"
    for i in range(channels):
        verilog_code += f"\t\t\t{bitsNeeded}'d{i}:\n"
        verilog_code += "\t\t\t\tbegin\n"
        for j in range(channels):
            if i == j:
                verilog_code += f"\t\t\t\t\t{outputs[j]} <= in;\n"
            else:
                verilog_code += f"\t\t\t\t\t{outputs[j]} <= {bitWidth}'d0;\n"
        verilog_code += "\t\t\t\tend\n"
    verilog_code += "\t\tendcase\n"
    verilog_code += "\tend\n"
    verilog_code += "endmodule\n"

    return verilog_code

def genReg(bitWidth):
    verilog_code = ""

    verilog_code += f"module reg{bitWidth} (\n"
    verilog_code += f"\tinput clk,\n"
    verilog_code += f"\tinput reset,\n"
    verilog_code += f"\tinput [{bitWidth - 1}:0] d,\n"
    verilog_code += f"\toutput reg [{bitWidth - 1}:0] q\n"
    verilog_code += f");\n"
    verilog_code += "\talways @(posedge clk or posedge reset) begin\n"
    verilog_code += "\t\tif (reset)\n"
    verilog_code += F"\t\t\tq <= {bitWidth}'d0;\n"
    verilog_code += "\t\telse\n"
    verilog_code += F"\t\t\tq <= d;\n"
    verilog_code += F"\tend\n"
    verilog_code += F"endmodule\n"

    return verilog_code


with open("rtl/modules/generated.v", "w") as f:
    code = ""
    code += genMux(2, 32)
    code += genMux(4, 32)
    code += genReg(32)
    f.write(code)
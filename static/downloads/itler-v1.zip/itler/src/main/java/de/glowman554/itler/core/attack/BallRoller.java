package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.EngineStalled;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.effect.Mass;
import de.glowman554.itler.core.player.AbstractPlayer;

public class BallRoller extends AbstractAttack
{
	public BallRoller()
	{
		super(15, 13, InGame.instance.getTranslation().get("attack.fat.ballroller").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{

		if (me.hasEffect(Mass.class) >= 3)
		{
			me.removeEffect(Fat.class, me.hasEffect(Fat.class));
			me.removeEffect(Mass.class, me.hasEffect(Mass.class));

			me.addEffect(new EngineStalled(2));

			other.dealDamage(getPhysicalDamageVariation(), me);
			other.dealMentalDamage(getMentalDamageVariation(), me);
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.fat.mass_needed").begin().replace("c", "3").end());
		}
	}
}

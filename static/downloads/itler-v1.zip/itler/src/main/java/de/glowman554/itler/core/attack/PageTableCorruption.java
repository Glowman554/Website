package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Corruption;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class PageTableCorruption extends AbstractAttack
{
	public PageTableCorruption()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.os.page_table_corruption").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new MentalConfusion(3));
		other.addEffect(new Corruption(2));
	}
}

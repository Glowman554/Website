package de.glowman554.itler.rendering;

import java.io.IOException;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.lazy.LazyShader;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderComponent;

public class BackgroundRenderer extends RenderComponent
{
	private LazyTexture background;
	private LazyShader shader;

	public BackgroundRenderer()
	{
		background = new LazyTexture("ui/background.jpg");
		shader = new LazyShader("shader/background/vertex.glsl", "shader/background/fragment.glsl");
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();

		try
		{
			applyShader(shader.getShaderProgram());
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		batch.draw(background.getTexture(), 0, 0);
		batch.end();
	}
}

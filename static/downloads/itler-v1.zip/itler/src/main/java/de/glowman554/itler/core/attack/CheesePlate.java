package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Cheese;
import de.glowman554.itler.core.effect.SchwaebischGood;
import de.glowman554.itler.core.player.AbstractPlayer;

public class CheesePlate extends AbstractAttack
{
	public CheesePlate()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.food.cheese_plate").begin().end());

	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Cheese(2));
		me.addEffect(new SchwaebischGood(2));
	}
}

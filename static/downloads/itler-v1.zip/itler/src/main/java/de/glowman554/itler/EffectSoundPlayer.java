package de.glowman554.itler;

import java.util.HashMap;

import de.glowman554.itler.core.effect.AbstractEffect;
import de.glowman554.itler.core.effect.EngineStalled;
import de.glowman554.itler.core.effect.Furry;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.effect.Perfect;
import de.glowman554.itler.core.events.PlayerEffectEvent;
import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.logging.Logger;

public class EffectSoundPlayer
{
	private HashMap<Class<? extends AbstractEffect>, LazySound> sounds = new HashMap<>();

	public EffectSoundPlayer()
	{
		sounds.put(Furry.class, new LazySound("sound/furry.mp3"));
		sounds.put(MentalConfusion.class, new LazySound("sound/confusion.mp3"));
		sounds.put(Perfect.class, new LazySound("sound/perfekt.mp3"));
		sounds.put(EngineStalled.class, new LazySound("sound/engine_stall.mp3"));
	}

	@EventTarget
	public void onPlayerEffectEvent(PlayerEffectEvent e)
	{
		if (sounds.containsKey(e.getClazz()))
		{
			Logger.log("Playing sound for " + e.getClazz().getSimpleName());
			sounds.get(e.getClazz()).getSound().play();
		}
	}
}

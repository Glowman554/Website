package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.ComingOutAsAFurry;
import de.glowman554.itler.core.attack.PageTableCorruption;
import de.glowman554.itler.core.attack.SchroedingersSyscall;
import de.glowman554.itler.core.attack.TailPunch;

public class Janick extends AbstractPlayer
{
	public Janick()
	{
		super(60, 60, new AbstractAttack[] {new ComingOutAsAFurry(), new TailPunch(), new PageTableCorruption(), new SchroedingersSyscall()});
	}
}

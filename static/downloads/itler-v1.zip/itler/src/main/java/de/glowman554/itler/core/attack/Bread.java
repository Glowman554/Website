package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Cheese;
import de.glowman554.itler.core.effect.Full;
import de.glowman554.itler.core.effect.Sausage;
import de.glowman554.itler.core.effect.SchwaebischGood;
import de.glowman554.itler.core.player.AbstractPlayer;

public class Bread extends AbstractAttack
{

	public Bread()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.food.bread").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		setPhysicalDamage((int) (10 * (0.5 * (me.hasEffect(Cheese.class) + me.hasEffect(Sausage.class)) - other.hasEffect(Full.class))));
		setMentalDamage(10 * me.hasEffect(SchwaebischGood.class));

		me.dealDamage(getPhysicalDamageVariation(), me);
		me.dealMentalDamage(getMentalDamageVariation(), me);

		me.addEffect(new Cheese(-me.hasEffect(Cheese.class)));
		me.addEffect(new Sausage(-me.hasEffect(Sausage.class)));
		me.addEffect(new SchwaebischGood(-me.hasEffect(SchwaebischGood.class)));
	}

}

package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public abstract class AbstractEffect
{
	private int level;

	public AbstractEffect(int level)
	{
		this.level = level;
	}

	public int getLevel()
	{
		return level;
	}

	public void setLevel(int level)
	{
		this.level = level;
	}

	public abstract boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me);

	public abstract boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me);

	public boolean decays()
	{
		return true;
	}

}

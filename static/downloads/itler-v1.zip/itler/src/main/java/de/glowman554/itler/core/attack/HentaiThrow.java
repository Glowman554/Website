package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Horny;
import de.glowman554.itler.core.player.AbstractPlayer;

public class HentaiThrow extends AbstractAttack
{
	public HentaiThrow()
	{
		super(20, 10, InGame.instance.getTranslation().get("attack.gay.hentai_throw").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Horny(3));
		other.addEffect(new Horny(2));

		other.dealMentalDamage(getMentalDamageVariation(), me);
		other.dealDamage(getPhysicalDamageVariation(), me);
	}
}

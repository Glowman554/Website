package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Furry;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class ComingOutAsAFurry extends AbstractAttack
{
	public ComingOutAsAFurry()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.furry.coming_out_as_furry").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(MentalConfusion.class) >= 1)
		{
			me.addEffect(new Furry(3));
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.furry.needs_mental_confusion").begin().end());
		}
	}
}

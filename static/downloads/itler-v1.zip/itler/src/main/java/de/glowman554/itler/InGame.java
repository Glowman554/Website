package de.glowman554.itler;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.itler.rendering.BackgroundRenderer;
import de.glowman554.itler.rendering.OverlayRenderer;
import de.glowman554.itler.rendering.PlayerRenderer;
import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.events.EventManager;
import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.input.KeyTypedEvent;
import de.glowman554.renderfox.language.AbstractTranslation;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.InputRenderer;
import de.glowman554.renderfox.utils.Point2D;

public class InGame extends GameScene
{
	public static InGame instance;

	private AbstractTranslation translation;

	private PlayerRenderer player1;
	private PlayerRenderer player2;

	private BackgroundRenderer backgroundRenderer;
	private OverlayRenderer overlayRenderer;
	private InputRenderer inputRenderer;

	private LazySound keysound;
	private LazySound death;

	private Class<? extends AbstractPlayer> player1Class;
	private Class<? extends AbstractPlayer> player2Class;

	private GameState gameState = GameState.PLAYER_1_MOVE;

	public InGame(Class<? extends AbstractPlayer> player1, Class<? extends AbstractPlayer> player2, AbstractTranslation translation)
	{
		instance = this;
		this.translation = translation;

		player1Class = player1;
		player2Class = player2;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void init() throws Exception
	{
		backgroundRenderer = new BackgroundRenderer();
		overlayRenderer = new OverlayRenderer();
		inputRenderer = new InputRenderer(new LazyTexture("ui/text_field_pride.png"), new Point2D(0, 0));

		keysound = new LazySound("sound/keysound.mp3");
		death = new LazySound("sound/feierabend-pommersche.mp3");

		EventManager.register(new EffectSoundPlayer());

		player1 = new PlayerRenderer(player1Class.newInstance());
		player2 = new PlayerRenderer(player2Class.newInstance());

		inputRenderer.ask(translation.get("player.move").begin().replace("p", "1").end());
		overlayRenderer.setPlayer(player1.getPlayer());
	}

	@Override
	public void update(RenderFox renderFox)
	{
		// TODO Auto-generated method stub
		switch (gameState)
		{
			case PLAYER_1_MOVE:
			{
				updatePlayer(player1.getPlayer(), "1", player2.getPlayer(), "2", GameState.PLAYER_1_DEAD, GameState.PLAYER_2_MOVE);
				break;
			}
			case PLAYER_2_MOVE:
			{
				updatePlayer(player2.getPlayer(), "2", player1.getPlayer(), "1", GameState.PLAYER_2_DEAD, GameState.PLAYER_1_MOVE);
				break;
			}

			case PLAYER_1_DEAD:
			case PLAYER_2_DEAD:
				break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + gameState);
		}

	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0.5f, 0.8f, 1f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		backgroundRenderer.render(font);

		switch (gameState)
		{
			case PLAYER_1_MOVE:
			{
				player1.render(font);
				overlayRenderer.render(font);
				inputRenderer.render(font);
				break;
			}
			case PLAYER_2_MOVE:
			{
				player2.render(font);
				overlayRenderer.render(font);
				inputRenderer.render(font);
				break;
			}

			case PLAYER_1_DEAD:
			case PLAYER_2_DEAD:
			{
				inputRenderer.render(font);

				if (inputRenderer.isAnswerReady())
				{
					Gdx.app.exit();
				}
			}
				break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + gameState);
		}
	}

	public void updatePlayer(AbstractPlayer attacker, String attackerId, AbstractPlayer other, String otherId, GameState deathState, GameState nextMoveState)
	{
		overlayRenderer.setPlayer(attacker);
		if (inputRenderer.isAnswerReady())
		{
			try
			{
				int selection = Integer.parseInt(inputRenderer.getAnswer());
				inputRenderer.reset();

				if (selection < 1 || selection > 4)
				{
					inputRenderer.ask(translation.get("player.move").begin().replace("p", attackerId).end());
				}
				else
				{
					try
					{
						attacker.attack(other, selection - 1);
						inputRenderer.ask(translation.get("player.move").begin().replace("p", otherId).end());
						gameState = nextMoveState;

					}
					catch (IllegalStateException e)
					{
						inputRenderer.ask(translation.get("player.move_error").begin().replace("p", attackerId).replace("e", e.getLocalizedMessage()).end());
					}
				}

			}
			catch (NumberFormatException e)
			{
				inputRenderer.ask(translation.get("player.move").begin().replace("p", attackerId).end());
			}
		}

		if (!attacker.isAlive())
		{
			inputRenderer.reset();
			inputRenderer.ask(translation.get("player.death").begin().replace("p", attackerId).end());
			death.getSound().play();
			gameState = deathState;
		}

	}

	public AbstractTranslation getTranslation()
	{
		return translation;
	}

	@EventTarget
	public void onKeyTyped(KeyTypedEvent e)
	{
		keysound.getSound().play();
	}

	public enum GameState
	{
		PLAYER_1_MOVE, PLAYER_2_MOVE, PLAYER_1_DEAD, PLAYER_2_DEAD
	}
}

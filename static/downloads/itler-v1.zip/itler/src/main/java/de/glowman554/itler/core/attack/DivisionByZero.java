package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.effect.The4thDimension;
import de.glowman554.itler.core.player.AbstractPlayer;

public class DivisionByZero extends AbstractAttack
{
	public DivisionByZero()
	{
		super(2, 0, InGame.instance.getTranslation().get("attack.4d.division_by_zero").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new MentalConfusion(3));
		me.addEffect(new The4thDimension(3));

		other.dealDamage(getMentalDamageVariation(), me);
		me.dealDamage(getMentalDamageVariation(), me);
	}
}

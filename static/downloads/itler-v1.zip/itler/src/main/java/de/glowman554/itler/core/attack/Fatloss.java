package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.effect.Mass;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class Fatloss extends AbstractAttack
{
	public Fatloss()
	{
		super(10, 10, InGame.instance.getTranslation().get("attack.fat.fatloss").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(Fat.class) >= 2)
		{
			if (me.hasEffect(Mass.class) >= 2)
			{
				me.removeEffect(Fat.class, 2);
				me.removeEffect(Mass.class, 2);

				me.dealDamage(10, me);
				me.dealMentalDamage(10, me);

				me.addEffect(new MentalConfusion(3));
				other.addEffect(new MentalConfusion(2));

				other.dealDamage(getPhysicalDamageVariation(), me);
				other.dealMentalDamage(getMentalDamageVariation(), me);
			}
			else
			{
				throw new IllegalStateException(InGame.instance.getTranslation().get("attack.fat.mass_needed").begin().replace("c", "2").end());
			}
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.fat.fat_needed").begin().replace("c", "2").end());
		}
	}
}

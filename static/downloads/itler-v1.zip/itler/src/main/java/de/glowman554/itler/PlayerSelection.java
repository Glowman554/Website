package de.glowman554.itler;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.itler.core.player.Adrian;
import de.glowman554.itler.core.player.Andreska;
import de.glowman554.itler.core.player.Franz;
import de.glowman554.itler.core.player.Janick;
import de.glowman554.itler.core.player.Lena;
import de.glowman554.itler.rendering.BackgroundRenderer;
import de.glowman554.itler.rendering.PlayerRenderer;
import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.language.AbstractTranslation;
import de.glowman554.renderfox.language.FileTranslation;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.ui.TextureButton;
import de.glowman554.renderfox.utils.Point2D;

public class PlayerSelection extends GameScene
{
	private AbstractTranslation translation;

	private BackgroundRenderer backgroundRenderer;

	private ArrayList<Class<? extends AbstractPlayer>> players = new ArrayList<>();
	private int current_selection = 0;

	private LazyTexture stickman;

	private TextureButton nextButton;
	private TextureButton prevButton;
	private TextureButton useButton;

	private Class<? extends AbstractPlayer> prev = null;

	private boolean selected = false;;

	public PlayerSelection(Class<? extends AbstractPlayer> prev)
	{
		this.prev = prev;
	}

	@Override
	public void init() throws Exception
	{
		translation = new FileTranslation(Gdx.files.internal("translation/de.trans").readString("UTF-8"));

		backgroundRenderer = new BackgroundRenderer();

		players.add(Adrian.class);
		players.add(Andreska.class);
		players.add(Franz.class);
		players.add(Janick.class);
		players.add(Lena.class);

		stickman = new LazyTexture("player/stickman.png");

		nextButton = new TextureButton(new Point2D(400, (72 + 8) * 2), new LazyTexture("ui/next.png"), () -> current_selection = (current_selection + 1) % players.size());
		prevButton = new TextureButton(new Point2D(400, (72 + 8) * 1), new LazyTexture("ui/prev.png"), () -> {
			if (current_selection <= 0)
			{
				current_selection = players.size() - 1;
			}
			else
			{
				current_selection--;
			}
		});
		useButton = new TextureButton(new Point2D(400, (72 + 8) * 0), new LazyTexture("ui/use.png"), () -> selected = true);
	}

	@Override
	public void update(RenderFox renderFox)
	{
		if (selected)
		{
			if (prev == null)
			{
				renderFox.transition(new PlayerSelection(players.get(current_selection)));
			}
			else
			{
				renderFox.transition(new InGame(prev, players.get(current_selection), translation));
			}
		}
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0.5f, 0.8f, 1f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		backgroundRenderer.render(font);

		batch.begin();

		batch.draw(PlayerRenderer.textures.get(players.get(current_selection)).getTexture(), 0, 0);
		batch.draw(stickman.getTexture(), 0, 0);

		nextButton.render(font);
		prevButton.render(font);
		useButton.render(font);

		font.setColor(Color.WHITE);
		font.draw(batch, translation.get("ui.player_select").begin().replace("p", prev == null ? "1" : "2").end(), 100 * 10, Gdx.graphics.getHeight() - 3 * 10 - 5);

		batch.end();
	}

}

package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Perfect;
import de.glowman554.itler.core.effect.The4thDimension;
import de.glowman554.itler.core.player.AbstractPlayer;

public class _4dPunch extends AbstractAttack
{
	public _4dPunch()
	{
		super(40, 20, InGame.instance.getTranslation().get("attack.4d.punch").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(The4thDimension.class) >= 1)
		{
			me.addEffect(new Perfect(2));
			other.dealDamage(getPhysicalDamageVariation(), me);
			other.dealMentalDamage(getMentalDamageVariation(), me);
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.4d.needs_4th_dimension").begin().end());
		}
	}
}

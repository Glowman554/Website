package de.glowman554.renderfox.rendering;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.input.KeyTypedEvent;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.logging.Logger;
import de.glowman554.renderfox.utils.Point2D;

public class InputRenderer extends RenderComponent
{
	private LazyTexture texture;
	private Point2D location;

	private String question = null;
	private String answer = "";
	private boolean answerReady = false;
	private Thread thread = null;

	public InputRenderer(LazyTexture texture, Point2D location)
	{
		this.texture = texture;
		this.location = location;
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();
		if (question != null)
		{
			batch.draw(texture.getTexture(), location.getX(), location.getY());
			font.setColor(Color.BLACK);
			font.draw(batch, question, 120, (texture.getTexture().getHeight() / 2) + (font.getCapHeight() + 5));
			font.draw(batch, "> " + answer, 120, (texture.getTexture().getHeight() / 2));
		}
		batch.end();
	}

	public void ask(final String question)
	{
		if (thread != null)
		{
			Logger.log("Waiting for old text animation to finish");
			try
			{
				thread.join();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}

		thread = new Thread(() -> {
			reset();
			this.question = "";
			int time_per_char = 500 / question.length();

			for (int i = 0; i < question.length(); i++)
			{
				this.question += question.charAt(i);
				try
				{
					Thread.sleep(time_per_char);
				}
				catch (InterruptedException e)
				{
					throw new RuntimeException(e);
				}
			}

			thread = null;
		});

		thread.start();
	}

	public String getAnswer()
	{
		return answer;
	}

	public boolean isAnswerReady()
	{
		return answerReady;
	}

	public void reset()
	{
		this.answer = "";
		this.answerReady = false;
	}

	@EventTarget
	public boolean onKeyTyped(KeyTypedEvent e)
	{
		if (question == null)
		{
			return false;
		}

		switch (e.getCharacter())
		{
			case '\b':
			{
				if (answer.length() != 0)
				{
					answer = answer.substring(0, answer.length() - 1);
				}
			}
				break;

			case '\n':
			{

				answerReady = true;
				question = null;

			}
				break;

			default:
			{
				answer += e.getCharacter();
			}
				break;
		}
		return false;
	}
}

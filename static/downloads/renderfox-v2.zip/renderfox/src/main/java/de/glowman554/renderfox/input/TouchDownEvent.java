package de.glowman554.renderfox.input;

import com.badlogic.gdx.Gdx;

import de.glowman554.renderfox.events.Event;

public class TouchDownEvent extends Event
{
	private int screenX;
	private int screenY;
	private int pointer;
	private int button;

	public TouchDownEvent(int screenX, int screenY, int pointer, int button)
	{
		this.screenX = screenX;
		this.screenY = Gdx.graphics.getHeight() - screenY;
		this.pointer = pointer;
		this.button = button;
	}

	public int getButton()
	{
		return button;
	}

	public int getPointer()
	{
		return pointer;
	}

	public int getScreenX()
	{
		return screenX;
	}

	public int getScreenY()
	{
		return screenY;
	}
}

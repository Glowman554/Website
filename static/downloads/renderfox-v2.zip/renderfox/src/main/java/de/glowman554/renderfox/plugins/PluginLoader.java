package de.glowman554.renderfox.plugins;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import de.glowman554.renderfox.logging.Logger;

public class PluginLoader
{
	private static File pluginDirectory;
	private static ArrayList<Object> pluginInstances = new ArrayList<Object>();

	public static void loadAll(String directory) throws IOException
	{
		pluginDirectory = new File(directory);

		if (!pluginDirectory.exists())
		{
			Logger.log(String.format("Creating plugin directory %s", pluginDirectory.getAbsoluteFile()));
			pluginDirectory.mkdir();
		}

		Files.walk(pluginDirectory.toPath()).forEach(PluginLoader::loader);

		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			deleteFolder(new File("external_assets"));
		}));
	}

	private static void deleteFolder(File folder)
	{
		if (folder.isDirectory())
		{
			File[] files = folder.listFiles();
			if (files != null)
			{
				for (File file : files)
				{
					deleteFolder(file);
				}
			}
		}

		Logger.log("Deleting: " + folder);

		if (!folder.delete())
		{
			Logger.log("Failed to delete folder: " + folder);
		}
	}

	private static void loader(Path path)
	{
		if (path.equals(pluginDirectory.toPath()))
		{
			return;
		}

		File f = path.toFile();
		if (!f.isFile())
		{
			Logger.log(String.format("[%s] Not a file!", f.getName()));
		}
		else
			if (f.getName().endsWith(".jar"))
			{
				Logger.log(String.format("[%s] Loading plugin...", f.getName()));
				try
				{
					PluginJar pl = new PluginJar(f.getAbsolutePath());

					Logger.log(String.format("[%s] Loading...", f.getName()));

					pluginInstances.add(pl.instantiate());

					Logger.log(String.format("[%s] Loaded!", f.getName()));

					pl.invokeEntrypoint();
				}
				catch (Exception e)
				{
					Logger.log(String.format("[%s] Failed to load plugin: %s", f.getName(), e.getMessage()));
				}
			}
			else
			{
				Logger.log("Unsupported plugin format for file: " + f.getName());
			}
	}
}

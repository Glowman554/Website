package de.glowman554.renderfox.events;

import java.util.ArrayList;

public class Event
{
	final ArrayList<EventData> dataList = EventManager.get(this.getClass());

	public Event call()
	{
		if (dataList != null)
		{
			for (EventData data : dataList)
			{
				try
				{
					data.target.invoke(data.source, this);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}
		return this;
	}
}
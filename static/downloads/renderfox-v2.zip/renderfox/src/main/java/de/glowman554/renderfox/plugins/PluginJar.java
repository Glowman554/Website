package de.glowman554.renderfox.plugins;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

import de.glowman554.renderfox.utils.StreamReader;

public class PluginJar
{
	private URLClassLoader child;

	private Object instance;
	private Class<?> mainClass;

	public PluginJar(String absolutePath) throws Exception
	{
		this.child = new URLClassLoader(new URL[] {new URL("jar:file:" + absolutePath + "!/")}, this.getClass().getClassLoader());

		try (InputStream entryClass = child.getResourceAsStream("entry.txt"))
		{
			String entryClassLoaded = StreamReader.readFile(entryClass);

			mainClass = (Class<?>) child.loadClass(entryClassLoaded);
		}
		catch (Exception e)
		{
			throw new Exception(e);
		}
	}

	@SuppressWarnings("deprecation")
	public Object instantiate() throws Exception
	{

		instance = mainClass.newInstance();

		return instance;
	}

	public void invokeEntrypoint() throws Exception
	{

		Method entry = null;
		PluginEntrypoint annot = null;
		for (Method m : mainClass.getMethods())
		{
			if (m.isAnnotationPresent(PluginEntrypoint.class))
			{
				entry = m;
				annot = m.getAnnotation(PluginEntrypoint.class);
			}
		}

		if (entry == null || annot == null)
		{
			throw new IllegalStateException("Pleae provide a @PluginEntrypoint function");
		}

		entry.invoke(instance);
	}

}

package de.glowman554.renderfox.rendering;

import de.glowman554.renderfox.events.Event;

public class RenderResourceDisposeEvent extends Event
{

}

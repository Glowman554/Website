package de.glowman554.renderfox.plugins;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;

import de.glowman554.renderfox.logging.Logger;

public class PluginAsset
{
	private static String asset_folder = "external_assets";
	private static HashMap<String, FileHandle> cache = new HashMap<>();

	public static FileHandle get(String path, Class<?> child)
	{
		if (cache.containsKey(path))
		{
			return cache.get(path);
		}

		File assets_folder = new File(asset_folder);
		if (!assets_folder.exists())
		{
			assets_folder.mkdir();
		}

		File output = new File(assets_folder, path);
		output.getParentFile().mkdirs();

		Logger.log("extracting " + path + " into " + asset_folder);

		try
		{
			InputStream is = child.getResourceAsStream("/" + path);
			FileOutputStream os = new FileOutputStream(output);
			int read;
			byte[] bytes = new byte[1024];

			while ((read = is.read(bytes)) != -1)
			{
				os.write(bytes, 0, read);
			}
			is.close();
			os.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return null;
		}

		FileHandle handle = Gdx.files.absolute(output.getAbsolutePath());
		cache.put(path, handle);

		return handle;
	}
}

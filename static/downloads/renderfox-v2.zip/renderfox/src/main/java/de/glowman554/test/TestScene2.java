package de.glowman554.test;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.input.KeyTypedEvent;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.ui.TextureButton;
import de.glowman554.renderfox.utils.Point2D;

public class TestScene2 extends GameScene
{
	private boolean transition = false;

	private TextureButton button;

	@Override
	public void init() throws Exception
	{
		button = new TextureButton(new Point2D(0, 0), new LazyTexture("test/splash.png"), () -> {
			transition = true;
		});
	}

	@Override
	public void update(RenderFox renderFox)
	{
		// TODO Auto-generated method stub
		if (transition)
		{
			renderFox.transition(new TestScene());
		}
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0.5f, 0.8f, 1f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		batch.begin();
		button.render(font);
		font.draw(batch, "Hello wowowowo rarara", 200, 200);
		batch.end();
	}

	@EventTarget
	public void onKeyTyped(KeyTypedEvent e)
	{
		if (e.getCharacter() == ' ')
		{
			transition = true;
		}
	}
}

package de.glowman554.renderfox.logging;

public class Logger
{
	public static void log(String message)
	{
		synchronized (Logger.class)
		{

			StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
			String new_message = "";
			for (String line : message.split("\n"))
			{
				new_message += String.format("[%s::%s at %s:%s] %s\n", stackTraceElements[2].getClassName(), stackTraceElements[2].getMethodName(), stackTraceElements[2].getFileName(), stackTraceElements[2].getLineNumber(), line);
			}

			// new_message = new_message.strip();

			// java 1.7 does not support String.strip()
			if (new_message.charAt(new_message.length() - 1) == '\n')
			{
				new_message = new_message.substring(0, new_message.length() - 1);
			}

			System.out.println(new_message);
		}
	}
}

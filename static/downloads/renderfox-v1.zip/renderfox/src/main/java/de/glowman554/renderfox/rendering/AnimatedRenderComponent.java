package de.glowman554.renderfox.rendering;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.lazy.LazyTexture;

public abstract class AnimatedRenderComponent extends RenderComponent
{
	private final long frame_time;
	private LazyTexture[] textures;

	private int idx = 0;

	public AnimatedRenderComponent(LazyTexture[] textures, long frame_time)
	{
		this.textures = textures;
		this.frame_time = frame_time;

	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		render(batch, font, textures[(int) (idx / frame_time) % textures.length]);
	}

	public void tick()
	{
		idx++;
	}

	public abstract void render(SpriteBatch batch, BitmapFont font, LazyTexture current);
}

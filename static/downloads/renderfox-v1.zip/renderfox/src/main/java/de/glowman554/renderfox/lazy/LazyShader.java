package de.glowman554.renderfox.lazy;

import java.io.IOException;
import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;

import de.glowman554.renderfox.logging.Logger;

public class LazyShader
{
	private static HashMap<String, ShaderProgram> loaded = new HashMap<>();

	private final String vertex_shader_path;
	private final String fragment_shader_path;

	public LazyShader(String vertex_shader_path, String fragment_shader_path)
	{
		this.vertex_shader_path = vertex_shader_path;
		this.fragment_shader_path = fragment_shader_path;

	}

	public ShaderProgram getShaderProgram() throws IOException
	{

		String key = vertex_shader_path + " / " + fragment_shader_path;
		if (!loaded.containsKey(key))
		{
			Logger.log("Loading shader " + key);

			String vertex = Gdx.files.internal(vertex_shader_path).readString();
			String fragment = Gdx.files.internal(fragment_shader_path).readString();

			loaded.put(key, new ShaderProgram(vertex, fragment));
		}

		return loaded.get(key);
	}

	public static void dispose()
	{
		for (var v : loaded.keySet())
		{

			Logger.log("Unloading " + v);
			loaded.get(v).dispose();
		}
	}
}

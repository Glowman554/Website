package de.glowman554.renderfox.timer;

public class Timer
{
	public static TimerTask runIn(Runnable r, int ms)
	{
		Thread t = new Thread(() -> {
			try
			{
				Thread.sleep(ms);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
			r.run();
		});
		t.start();
		return new TimerTask(t);
	}

	public static TimerTask repeatEvery(Runnable r, int ms)
	{
		Thread t = new Thread(() -> {
			while (true)
			{
				try
				{
					Thread.sleep(ms);
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				r.run();
			}
		});
		t.start();
		return new TimerTask(t);
	}
}

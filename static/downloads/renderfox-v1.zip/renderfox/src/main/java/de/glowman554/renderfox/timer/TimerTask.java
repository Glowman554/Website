package de.glowman554.renderfox.timer;

import de.glowman554.renderfox.events.EventManager;
import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.logging.Logger;
import de.glowman554.renderfox.rendering.RenderResourceDisposeEvent;

public class TimerTask
{
	private final Thread thread;

	public TimerTask(Thread thread)
	{
		this.thread = thread;
		EventManager.register(this);
	}

	public void cancle()
	{
		thread.stop();
		EventManager.unregister(this);
	}

	@EventTarget
	public void onDispose(RenderResourceDisposeEvent e)
	{
		Logger.log("Disposing timer task");
		thread.stop();
	}
}

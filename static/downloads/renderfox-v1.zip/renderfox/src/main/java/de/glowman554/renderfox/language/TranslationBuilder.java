package de.glowman554.renderfox.language;

import java.util.ArrayList;
import java.util.Arrays;

public class TranslationBuilder
{
	private final String trans;
	private final ArrayList<String> needed_replacements;

	public TranslationBuilder(String trans, String[] needed_replacements)
	{
		this.trans = trans;
		this.needed_replacements = new ArrayList<>(Arrays.stream(needed_replacements).toList());
	}

	public TranslationComponentInstance begin()
	{
		return new TranslationComponentInstance(trans, new ArrayList<>(needed_replacements));
	}

	public class TranslationComponentInstance
	{
		private final ArrayList<String> needed_replacements;
		private String trans;

		public TranslationComponentInstance(String trans, ArrayList<String> needed_replacements)
		{
			this.trans = trans;
			this.needed_replacements = needed_replacements;
		}

		public TranslationComponentInstance replace(String what, String with)
		{
			if (!needed_replacements.contains(what))
			{
				throw new IllegalArgumentException("Invalid replacement " + what);
			}
			else
			{
				trans = trans.replace("%" + what + "%", with);
				needed_replacements.remove(what);
			}

			return this;
		}

		public String end()
		{
			return trans;
		}
	}
}

package de.glowman554.renderfox.rendering;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.timer.Timer;

public class SplashScreen extends GameScene
{
	private boolean transition = false;

	private final GameScene transitionTo;
	private final int ms;

	private LazyTexture texture;

	public SplashScreen(LazyTexture texture, GameScene transitionTo, int ms)
	{
		this.transitionTo = transitionTo;
		this.ms = ms;
		this.texture = texture;
	}

	@Override
	public void init() throws Exception
	{
		Timer.runIn(() -> transition = true, ms);
	}

	@Override
	public void update(RenderFox renderFox)
	{
		if (transition)
		{
			renderFox.transition(transitionTo);
		}
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		int x = Gdx.graphics.getWidth() / 2 - texture.getTexture().getWidth() / 2;
		int y = Gdx.graphics.getHeight() / 2 - texture.getTexture().getHeight() / 2;

		batch.begin();
		batch.draw(texture.getTexture(), x, y);
		batch.end();
	}

}

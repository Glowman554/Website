package de.glowman554.renderfox.language;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.glowman554.renderfox.logging.Logger;

public class FileTranslation extends AbstractTranslation
{
	private final String translation;

	public FileTranslation(String translation)
	{
		this.translation = translation;

		prepare();
	}

	@Override
	public void registerTranslations()
	{
		int translations_loaded = 0;
		for (String line : translation.split("\n"))
		{
			if (line.strip().equals(""))
			{
				continue;
			}

			String[] line_split = line.split(":->");

			ArrayList<String> replacements = new ArrayList<>();

			for (Matcher m = Pattern.compile("%\\w+%").matcher(line_split[1]); m.find();)
			{
				String match = m.group().substring(1);
				match = match.substring(0, match.length() - 1);

				if (!replacements.contains(match))
				{
					replacements.add(match);
				}
			}

			register(line_split[0], new TranslationBuilder(line_split[1], replacements.toArray(new String[0])));

			translations_loaded++;
		}

		Logger.log("Parsed " + translations_loaded + " translations!");
	}
}

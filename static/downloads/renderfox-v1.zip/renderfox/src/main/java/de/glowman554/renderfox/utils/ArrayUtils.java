package de.glowman554.renderfox.utils;

public class ArrayUtils<T1>
{
	public T1[] rotate(T1[] arr)
	{
		T1 tmp = arr[0];
		for (int i = 1; i < arr.length; i++)
		{
			arr[i - 1] = arr[i];
		}

		arr[arr.length - 1] = tmp;

		return arr;
	}

	public String toStr(T1[] arr)
	{
		String out = "";
		for (int i = 0; i < arr.length; i++)
		{
			out += arr[i] + ((i + 1 < arr.length) ? ", " : "");
		}

		return out;
	}
}
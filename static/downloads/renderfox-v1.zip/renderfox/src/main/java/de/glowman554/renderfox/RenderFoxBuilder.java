package de.glowman554.renderfox;

import javax.swing.JOptionPane;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;

public class RenderFoxBuilder
{
	private Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
	private String title = "RenderFox";

	public RenderFoxBuilder()
	{
		config.setResizable(false);
		config.setTitle("RenderFox");
	}

	public RenderFoxBuilder targetFPS(int fps)
	{
		config.setForegroundFPS(fps);
		return this;
	}

	public RenderFoxBuilder size(int w, int h)
	{
		config.setWindowedMode(w, h);
		return this;
	}

	public RenderFoxBuilder title(String title)
	{
		this.title = title;
		return this;
	}

	public void launch(GameScene scene)
	{
		try
		{

			new Lwjgl3Application(new RenderFox(scene, title), config);
		}
		catch (Exception e)
		{
			e.printStackTrace();

			JOptionPane.showMessageDialog(null, e.toString(), "Game Crashed", JOptionPane.ERROR_MESSAGE);

			Gdx.app.exit();
		}
	}
}

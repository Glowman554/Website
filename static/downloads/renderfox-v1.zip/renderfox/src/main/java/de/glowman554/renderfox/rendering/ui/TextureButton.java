package de.glowman554.renderfox.rendering.ui;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.events.EventTarget;
import de.glowman554.renderfox.input.TouchDownEvent;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderComponent;
import de.glowman554.renderfox.utils.Point2D;

public class TextureButton extends RenderComponent
{

	private final Point2D location;
	private final LazyTexture texture;
	private final Runnable onclick;

	public TextureButton(Point2D location, LazyTexture texture, Runnable onclick)
	{
		this.location = location;
		this.texture = texture;
		this.onclick = onclick;
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();
		batch.draw(texture.getTexture(), location.getX(), location.getY());
		batch.end();
	}

	@EventTarget
	public void onTouchDown(TouchDownEvent e)
	{
		if (e.getScreenX() > location.getX() && e.getScreenX() < location.getX() + texture.getTexture().getWidth())
		{
			if (e.getScreenY() > location.getY() && e.getScreenY() < location.getY() + texture.getTexture().getHeight())
			{
				onclick.run();
			}
		}
	}

	public Point2D getLocation()
	{
		return location;
	}
}

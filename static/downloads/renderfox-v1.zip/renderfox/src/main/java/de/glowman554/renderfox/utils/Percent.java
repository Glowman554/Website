package de.glowman554.renderfox.utils;

public class Percent
{
	public static int percent_of(int in, int percent)
	{
		return (int) (in * (percent / 100.0f));
	}
}

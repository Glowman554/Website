package de.glowman554.renderfox.input;

import de.glowman554.renderfox.events.Event;

public class KeyTypedEvent extends Event
{
	private char character;

	public KeyTypedEvent(char character)
	{
		this.character = character;
	}

	public char getCharacter()
	{
		return character;
	}
}

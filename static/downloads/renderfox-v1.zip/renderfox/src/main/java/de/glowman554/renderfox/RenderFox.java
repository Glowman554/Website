package de.glowman554.renderfox;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;

import de.glowman554.renderfox.events.EventManager;
import de.glowman554.renderfox.input.InputEventProcessor;
import de.glowman554.renderfox.lazy.LazyShader;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderResourceDisposeEvent;

public class RenderFox extends ApplicationAdapter
{

	private GameScene current;
	private BitmapFont font;
	private String title;

	public RenderFox(GameScene scene, String title) throws Exception
	{
		current = scene;
		this.title = title;
	}

	@Override
	public void create()
	{
		super.create();

		new InputEventProcessor();

		font = new BitmapFont(Gdx.files.internal("font/Calibri.fnt"), false);

		transition(current);
	}

	public void transition(GameScene next)
	{
		new RenderResourceDisposeEvent().call();
		EventManager.reset();
		EventManager.register(next);
		current = next;
		try
		{
			current.init();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			Gdx.app.exit();
		}
	}

	@Override
	public void render()
	{
		current.update(this);
		current.render(font);
		super.render();

		Gdx.graphics.setTitle(title + " | " + Gdx.graphics.getFramesPerSecond() + " FPS");
	}

	@Override
	public void dispose()
	{
		super.dispose();
		font.dispose();

		new RenderResourceDisposeEvent().call();

		LazyTexture.dispose();
		LazyShader.dispose();
		LazySound.dispose();
	}
}

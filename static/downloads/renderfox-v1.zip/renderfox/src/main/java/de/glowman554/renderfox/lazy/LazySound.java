package de.glowman554.renderfox.lazy;

import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;

import de.glowman554.renderfox.logging.Logger;

public class LazySound
{
	private static HashMap<String, Sound> loaded = new HashMap<>();

	private final String sound_path;

	public LazySound(String sound_path)
	{
		this.sound_path = sound_path;
	}

	public Sound getSound()
	{
		if (!loaded.containsKey(sound_path))
		{
			Logger.log("Loading sound " + sound_path);
			loaded.put(sound_path, Gdx.audio.newSound(Gdx.files.internal(sound_path)));
		}

		return loaded.get(sound_path);
	}

	public static void dispose()
	{
		for (var v : loaded.keySet())
		{

			Logger.log("Unloading " + v);
			loaded.get(v).dispose();
		}
	}
}

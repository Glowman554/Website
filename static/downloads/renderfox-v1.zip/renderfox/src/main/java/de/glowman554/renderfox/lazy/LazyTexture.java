package de.glowman554.renderfox.lazy;

import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

import de.glowman554.renderfox.logging.Logger;

public class LazyTexture
{
	private static HashMap<String, Texture> loaded = new HashMap<>();

	private final String texture_path;

	public LazyTexture(String texture_path)
	{
		this.texture_path = texture_path;
	}

	public Texture getTexture()
	{
		if (!loaded.containsKey(texture_path))
		{
			Logger.log("Loading texture " + texture_path);
			loaded.put(texture_path, new Texture(Gdx.files.internal(texture_path)));
		}

		return loaded.get(texture_path);
	}

	public static void dispose()
	{
		for (var v : loaded.keySet())
		{

			Logger.log("Unloading " + v);
			loaded.get(v).dispose();
		}
	}
}

package de.glowman554.renderfox;

import de.glowman554.renderfox.rendering.RenderComponent;

public abstract class GameScene extends RenderComponent
{

	public abstract void init() throws Exception;

	public abstract void update(RenderFox renderFox);

}

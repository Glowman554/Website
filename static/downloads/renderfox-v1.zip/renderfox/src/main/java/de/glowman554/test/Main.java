package de.glowman554.test;

import java.io.IOException;

import de.glowman554.renderfox.RenderFoxBuilder;

public class Main
{
	public static void main(String[] args) throws IOException
	{
		new RenderFoxBuilder().targetFPS(60).size(1000, 1000).title("RenderFox Test").launch(new TestScene());
	}
}

package de.glowman554.renderfox.language;

import java.util.HashMap;

import de.glowman554.renderfox.logging.Logger;

public abstract class AbstractTranslation
{
	private HashMap<String, TranslationBuilder> translations = new HashMap<>();

	public void prepare()
	{
		Logger.log("Preparing translations");

		registerTranslations();
	}

	public void register(String translation, TranslationBuilder translationBuilder)
	{
		// MainGame.instance.dbg("Registering translation " + translation);
		translations.put(translation, translationBuilder);
	}

	public TranslationBuilder get(String translation)
	{
		if (translations.get(translation) == null)
		{
			throw new IllegalArgumentException("Translation " + translation + " not found!");
		}
		return translations.get(translation);
	}

	public abstract void registerTranslations();
}

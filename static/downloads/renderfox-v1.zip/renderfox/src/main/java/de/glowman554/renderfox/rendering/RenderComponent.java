package de.glowman554.renderfox.rendering;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;

import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.events.EventManager;
import de.glowman554.renderfox.events.EventTarget;

public abstract class RenderComponent
{
	private SpriteBatch batch;

	public abstract void render(SpriteBatch batch, BitmapFont font);

	private double shader_speed = .03;
	private double shader_change = shader_speed;

	public RenderComponent()
	{
		if (!(this instanceof GameScene))
		{
			EventManager.register(this);
		}
	}

	public void render(BitmapFont font)
	{
		shader_change += shader_speed;

		if (batch == null)
		{
			batch = new SpriteBatch();
		}

		render(batch, font);
	}

	public void applyShader(ShaderProgram shader)
	{
		shader.setUniformf("u_shader_change", (float) shader_change);
		batch.setShader(shader);
	}

	@Deprecated
	public void reset_batch()
	{
		batch.dispose();
		batch = new SpriteBatch();
	}

	@EventTarget
	public void onDispose(RenderResourceDisposeEvent e)
	{
		if (batch != null)
		{
			batch.dispose();
		}
	}

	public SpriteBatch getBatch()
	{
		return batch;
	}
}
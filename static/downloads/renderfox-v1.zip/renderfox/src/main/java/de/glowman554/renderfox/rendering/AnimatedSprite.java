package de.glowman554.renderfox.rendering;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.utils.Point2D;

public class AnimatedSprite extends AnimatedRenderComponent
{
	private Point2D location;

	public AnimatedSprite(LazyTexture[] textures, long frame_time, Point2D location)
	{
		super(textures, frame_time);
		this.location = location;
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font, LazyTexture current)
	{
		batch.begin();
		batch.draw(current.getTexture(), location.getX(), location.getY());
		batch.end();
	}

}

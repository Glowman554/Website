set -e

bash prepare.sh

GOWIN=./IDE/
if [ ! -d "$GOWIN" ]; then
    echo "Please put the IDE folder from the Gowin EDA download package here: $GOWIN"
    exit 1
fi

GOWIN_SH=$GOWIN/bin/gw_sh
GOWIN_DEVICE="GW2A-18C GW2A-LV18PG256C8/I7"

mkdir -p impl

echo "set_device -name $GOWIN_DEVICE" > impl/run.tcl
echo "set_option -top_module top" >> impl/run.tcl

for file in fpga/*.v soc/*.v soc/core/*.v soc/extensions/*.v; do
    if [[ -f "$file" ]]; then
        echo "add_file $file" >> impl/run.tcl
    fi
done


echo "add_file fpga/top.cst" >> impl/run.tcl
echo "add_file fpga/top.sdc" >> impl/run.tcl
echo "set_option -use_sspi_as_gpio 1" >> impl/run.tcl
echo "run all" >> impl/run.tcl

$GOWIN_SH impl/run.tcl

#sudo openFPGALoader impl/pnr/project.fs --external-flash
# sudo openFPGALoader impl/pnr/project.fs
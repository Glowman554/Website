set -ex

bash prepare.sh

iverilog -o /tmp/run sim/*.v soc/*.v soc/core/*.v soc/extensions/*.v
vvp /tmp/run -lxt2
gtkwave dump.lxt
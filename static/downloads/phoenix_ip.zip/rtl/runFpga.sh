set -e

bash buildFpga.sh

sudo openFPGALoader impl/pnr/project.fs --board tangprimer20k -v


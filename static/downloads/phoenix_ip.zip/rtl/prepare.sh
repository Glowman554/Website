set -e

echo "Das Disaster beggint (Es wird Gottlos)"
echo "I have been coding for 8 hours and now I'm dying with errors and can't code anymore"
echo "Hell is forever whether you like it or not"
echo "There is no use in trying to fight it"

phoenixv2-microcode

read -p "Test? " test

cp ../tests/$test.hex firmware.hex
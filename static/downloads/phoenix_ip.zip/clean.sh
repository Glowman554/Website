(
    cd uploader
    rm -rfv build pico-sdk
)

(
    cd tests
    make clean
)

(
    cd rtl
    rm -rfv *.hex *.bin *.lxt impl IDE
)
if [ ! -d "pico-sdk" ]; then
    git clone https://github.com/raspberrypi/pico-sdk --recurse
fi

mkdir -p build
(
    cd build
    cmake ..
    # cmake -DCMAKE_BUILD_TYPE=Debug ..
    make -j 4
)

package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class Full extends AbstractEffect
{

	public Full(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return true;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return true;
	}

	@Override
	public boolean decays()
	{
		return false;
	}

}

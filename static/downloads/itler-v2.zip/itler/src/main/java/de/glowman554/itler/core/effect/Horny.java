package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class Horny extends AbstractEffect
{

	public Horny(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return Math.random() < 0.9;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return Math.random() < 0.9;
	}

}

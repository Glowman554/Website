package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class Corruption extends AbstractEffect
{

	public Corruption(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return Math.random() < 0.5;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return Math.random() < 0.5;
	}

}

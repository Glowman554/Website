package de.glowman554.itler.rendering;

import java.io.IOException;
import java.util.HashMap;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.itler.core.effect.AbstractEffect;
import de.glowman554.itler.core.effect.Cheese;
import de.glowman554.itler.core.effect.Corruption;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.itler.core.player.Adrian;
import de.glowman554.itler.core.player.Andreska;
import de.glowman554.itler.core.player.Denis;
import de.glowman554.itler.core.player.Franz;
import de.glowman554.itler.core.player.Janick;
import de.glowman554.itler.core.player.Lena;
import de.glowman554.renderfox.lazy.LazyShader;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderComponent;

public class PlayerRenderer extends RenderComponent
{

	public final static HashMap<Class<? extends AbstractPlayer>, LazyTexture> textures = new HashMap<>();
	public final static HashMap<Class<? extends AbstractEffect>, LazyShader> shaders = new HashMap<>();

	static
	{
		textures.put(Adrian.class, new LazyTexture("player/adrian.png"));
		textures.put(Franz.class, new LazyTexture("player/franz.png"));
		textures.put(Lena.class, new LazyTexture("player/lena.png"));
		textures.put(Janick.class, new LazyTexture("player/janick.png"));
		textures.put(Andreska.class, new LazyTexture("player/andreska.png"));
		textures.put(Denis.class, new LazyTexture("player/denis.png"));

		shaders.put(Cheese.class, new LazyShader("shader/food/vertex.glsl", "shader/food/fragment.glsl"));
		shaders.put(Corruption.class, new LazyShader("shader/corruption/vertex.glsl", "shader/corruption/fragment.glsl"));
		shaders.put(MentalConfusion.class, new LazyShader("shader/lsd/vertex.glsl", "shader/lsd/fragment.glsl"));
	}

	private LazyTexture stickman;
	private LazyTexture playerTexture;
	private AbstractPlayer player;

	public PlayerRenderer(AbstractPlayer player)
	{
		stickman = new LazyTexture("player/stickman.png");
		playerTexture = textures.get(player.getClass());
		this.player = player;
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();

		LazyShader shader = null;
		for (AbstractEffect effect : player.getEffects())
		{
			shader = shaders.get(effect.getClass());

			if (shader != null)
			{
				break;
			}
		}

		if (shader != null)
		{
			try
			{
				applyShader(shader.getShaderProgram());
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			batch.setShader(null);
		}

		batch.draw(playerTexture.getTexture(), 0, 0);
		batch.draw(stickman.getTexture(), 0, 0);

		batch.end();
	}

	public AbstractPlayer getPlayer()
	{
		return player;
	}
}

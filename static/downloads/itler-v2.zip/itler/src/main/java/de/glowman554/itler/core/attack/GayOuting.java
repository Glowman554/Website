package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Gay;
import de.glowman554.itler.core.player.AbstractPlayer;

public class GayOuting extends AbstractAttack
{
	public GayOuting()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.gay.gay_outing").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Gay(3));

	}
}

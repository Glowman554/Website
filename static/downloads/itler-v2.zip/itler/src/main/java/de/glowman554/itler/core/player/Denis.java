package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.Blyat;
import de.glowman554.itler.core.attack.Moscow;
import de.glowman554.itler.core.attack.RussianCooking;
import de.glowman554.itler.core.attack.VodkaShot;

public class Denis extends AbstractPlayer
{
	// Effect: Russian (only allow hits from other Russians)
	// Effect: drunk (only mental damage)
	// Attack: Blyat (me + 2 Russian (effect), me needs drunk)
	// Attack: Vodka shot anbiten (other + 2 drunk, me + 2 drunk)
	// Attack: Moskau fahrt
	// Attack: Russische Küche (heal self)
	
	// TODO: sounds & textures
	

	public Denis()
	{
		super(60, 60, new AbstractAttack[] { new Blyat(), new VodkaShot(), new Moscow(), new RussianCooking() });
	}
}

package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.BallRoller;
import de.glowman554.itler.core.attack.Fatabsorbtion;
import de.glowman554.itler.core.attack.Fatloss;
import de.glowman554.itler.core.attack.SpeedOfLight;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.effect.Mass;

public class Andreska extends AbstractPlayer
{
	public Andreska()
	{
		super(60, 60, new AbstractAttack[] {new Fatloss(), new BallRoller(), new Fatabsorbtion(), new SpeedOfLight()});
		addEffect(new Mass(6));
		addEffect(new Fat(5));

	}
}

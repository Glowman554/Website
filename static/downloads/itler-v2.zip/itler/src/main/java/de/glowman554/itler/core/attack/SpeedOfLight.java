package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.effect.Mass;
import de.glowman554.itler.core.player.AbstractPlayer;

public class SpeedOfLight extends AbstractAttack
{

	public SpeedOfLight()
	{
		super(0, 40, InGame.instance.getTranslation().get("attack.fat.speedoflight").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(Fat.class) == 10)
		{
			if (me.hasEffect(Mass.class) == 0)
			{
				other.dealDamage(getPhysicalDamageVariation(), me);
			}
			else
			{
				throw new IllegalStateException(InGame.instance.getTranslation().get("attack.fat.no_mass").begin().end());
			}
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.fat.fat_needed_exactly").begin().replace("c", "10").end());
		}
	}

}

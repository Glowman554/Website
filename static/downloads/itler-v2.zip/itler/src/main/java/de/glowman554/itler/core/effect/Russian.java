package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class Russian extends AbstractEffect
{

	public Russian(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return other.hasEffect(Russian.class) != 0 || me == other;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return other.hasEffect(Russian.class) != 0 || me == other;
	}


}

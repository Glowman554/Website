package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Gay;
import de.glowman554.itler.core.player.AbstractPlayer;

public class GaySlap extends AbstractAttack
{
	public GaySlap()
	{
		super(40, 20, InGame.instance.getTranslation().get("attack.gay.gay_slap").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(Gay.class) >= 1)
		{
			other.dealDamage(getPhysicalDamageVariation(), me);
			other.dealMentalDamage(getMentalDamageVariation(), me);
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.gay.gay_needed").begin().end());
		}
	}
}

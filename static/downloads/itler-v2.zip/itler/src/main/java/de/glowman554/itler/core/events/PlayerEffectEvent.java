package de.glowman554.itler.core.events;

import de.glowman554.itler.core.effect.AbstractEffect;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.renderfox.events.Event;

public class PlayerEffectEvent extends Event
{
	private AbstractPlayer abstractPlayer;
	private Class<? extends AbstractEffect> clazz;

	public PlayerEffectEvent(AbstractPlayer abstractPlayer, Class<? extends AbstractEffect> clazz)
	{
		this.abstractPlayer = abstractPlayer;
		this.clazz = clazz;
	}

	public Class<? extends AbstractEffect> getClazz()
	{
		return clazz;
	}

	public AbstractPlayer getAbstractPlayer()
	{
		return abstractPlayer;
	}
}

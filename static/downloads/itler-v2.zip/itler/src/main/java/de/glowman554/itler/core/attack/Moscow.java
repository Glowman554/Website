package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.renderfox.lazy.LazySound;

public class Moscow extends AbstractAttack
{
	private LazySound sound = new LazySound("sound/moscow.mp3");

	public Moscow()
	{
		super(30, 30, InGame.instance.getTranslation().get("attack.russian.moscow").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		sound.getSound().play();
		
		other.dealDamage(getPhysicalDamageVariation(), me);
		other.dealMentalDamage(getMentalDamageVariation(), me);
	}
}

package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.effect.The4thDimension;
import de.glowman554.itler.core.player.AbstractPlayer;

public class _4dDoge extends AbstractAttack
{

	public _4dDoge()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.4d.doge").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(MentalConfusion.class) >= 4)
		{
			me.addEffect(new The4thDimension(3));
			me.removeEffect(MentalConfusion.class, 3);

		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.4d.needs_mental_confusion").begin().replace("c", "4").end());
		}
	}

}

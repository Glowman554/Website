package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Corruption;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.player.AbstractPlayer;

public class Fatabsorbtion extends AbstractAttack
{
	public Fatabsorbtion()
	{
		super(10, 20, InGame.instance.getTranslation().get("attack.fat.fatabsorbtion").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Fat(10 - me.hasEffect(Fat.class)));

		me.dealMentalDamage(2, me);

		other.dealDamage(getPhysicalDamageVariation(), me);
		other.dealMentalDamage(getMentalDamageVariation(), me);

		other.addEffect(new Corruption(1));
	}
}

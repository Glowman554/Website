package de.glowman554.itler;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.renderfox.GameScene;
import de.glowman554.renderfox.RenderFox;
import de.glowman554.renderfox.lazy.LazySound;
import de.glowman554.renderfox.logging.Logger;

public class PreLaunch extends GameScene
{

	@Override
	public void init() throws Exception
	{
		new Thread(() -> {
			new LazySound("sound/runaway.mp3").getSound().loop((float) .1);
			Logger.log("Started background music");

		}).start();

	}

	@Override
	public void update(RenderFox renderFox)
	{
		renderFox.transition(new PlayerSelection(null));
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		// TODO Auto-generated method stub

	}

}

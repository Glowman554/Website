package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Russian;
import de.glowman554.itler.core.player.AbstractPlayer;

public class RussianCooking extends AbstractAttack
{

	public RussianCooking()
	{
		super(-10, -10, InGame.instance.getTranslation().get("attack.russian.russian_cooking").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Russian(2));
		
		me.dealDamage(getPhysicalDamageVariation(), me);
		me.dealMentalDamage(getMentalDamageVariation(), me);
	}

}

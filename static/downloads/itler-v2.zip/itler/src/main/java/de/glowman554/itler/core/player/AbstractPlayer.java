package de.glowman554.itler.core.player;

import java.util.ArrayList;
import java.util.HashMap;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.effect.AbstractEffect;
import de.glowman554.itler.core.events.PlayerEffectEvent;
import de.glowman554.renderfox.logging.Logger;

public class AbstractPlayer
{
	private static HashMap<String, Class<? extends AbstractPlayer>> playerLookup = new HashMap<>();
	
	static 
	{
		Logger.log("Populating player lookup");
		
		playerLookup.put("franz", Franz.class);
		playerLookup.put("janick", Janick.class);
		playerLookup.put("adrian", Adrian.class);
		playerLookup.put("lena", Lena.class);
		playerLookup.put("andreska", Andreska.class);
		playerLookup.put("denis", Denis.class);
	}

	private final AbstractAttack[] attacks;
	private final int orig_health;
	private final int orig_intelligence;
	private int health;
	private int intelligence;
	private ArrayList<AbstractEffect> effects = new ArrayList<>();
	
	private int lastPhysicalAttack = 0;
	private int lastMentalAttack = 0;

	public AbstractPlayer(int health, int intelligence, AbstractAttack[] attacks)
	{
		this.health = health;
		this.intelligence = intelligence;
		this.attacks = attacks;

		orig_health = health;
		orig_intelligence = intelligence;

		Logger.log("New player: " + getClass().getSimpleName());
	}

	public void addEffect(AbstractEffect new_effect)
	{
		if (new_effect.getLevel() > 0)
		{
			new PlayerEffectEvent(this, new_effect.getClass()).call();
		}
		for (AbstractEffect effect : effects)
		{
			if (effect.getClass() == new_effect.getClass())
			{
				effect.setLevel(effect.getLevel() + new_effect.getLevel());
				return;
			}
		}

		effects.add(new_effect);
	}

	public int hasEffect(Class<? extends AbstractEffect> clazz)
	{
		for (AbstractEffect effect : effects)
		{
			if (effect.getClass() == clazz)
			{
				return effect.getLevel();
			}
		}

		return 0;
	}

	public void removeEffect(Class<? extends AbstractEffect> clazz, int amount)
	{
		AbstractEffect effect_to_remove = null;
		for (AbstractEffect effect : effects)
		{
			if (effect.getClass() == clazz)
			{
				effect_to_remove = effect;
			}
		}

		if (effect_to_remove.getLevel() < amount)
		{
			effects.remove(effect_to_remove);
		}
		else
		{
			effect_to_remove.setLevel(effect_to_remove.getLevel() - amount);
		}
	}

	private void decreaseEffects()
	{
		ArrayList<AbstractEffect> to_be_removed = new ArrayList<>();
		for (AbstractEffect effect : effects)
		{
			if (effect.decays() || effect.getLevel() <= 0)
			{
				if (effect.getLevel() <= 1)
				{
					to_be_removed.add(effect);
				}
				else
				{
					effect.setLevel(effect.getLevel() - 1);
				}
			}
		}

		for (AbstractEffect effect : to_be_removed)
		{
			effects.remove(effect);
		}
	}

	public void dealDamage(int damage, AbstractPlayer dealer)
	{
		for (AbstractEffect effect : effects)
		{
			if (!effect.allowPhysicalDamage(dealer, this))
			{
				Logger.log("Dropping damage: " + damage);
				return;
			}
		}

		Logger.log("Dealing damage: " + damage);
		health -= damage;
		lastPhysicalAttack = damage;
	}

	public void dealMentalDamage(int damage, AbstractPlayer dealer)
	{
		for (AbstractEffect effect : effects)
		{
			if (!effect.allowMentalDamage(dealer, this))
			{
				Logger.log("Dropping damage: " + damage);
				return;
			}
		}

		Logger.log("Dealing mental damage: " + damage);
		intelligence -= damage;
		lastMentalAttack = damage;
	}

	public void attack(AbstractPlayer other, int num_attack)
	{
		lastMentalAttack = 0;
		lastPhysicalAttack = 0;
		
		attacks[num_attack].attack(other, this);

		decreaseEffects();
	}

	public boolean isAlive()
	{
		return health > 0 && intelligence > 0;
	}

	public int getHealth()
	{
		return health;
	}

	public int getIntelligence()
	{
		return intelligence;
	}

	public int getOrigHealth()
	{
		return orig_health;
	}

	public int getOrigIntelligence()
	{
		return orig_intelligence;
	}
	
	public int getLastMentalAttack()
	{
		return lastMentalAttack;
	}
	
	public int getLastPhysicalAttack()
	{
		return lastPhysicalAttack;
	}

	public AbstractAttack[] getAttacks()
	{
		return attacks;
	}

	public ArrayList<AbstractEffect> getEffects()
	{
		return effects;
	}
	
	public static HashMap<String, Class<? extends AbstractPlayer>> getPlayerLookup()
	{
		return playerLookup;
	}
}

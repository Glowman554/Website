package de.glowman554.itler.core.attack;

import de.glowman554.itler.core.player.AbstractPlayer;

public abstract class AbstractAttack
{
	private final String desc;
	private int mental_damage;
	private int physical_damage;

	protected AbstractAttack(int mental_damage, int physical_damage, String desc)
	{
		this.mental_damage = mental_damage;
		this.physical_damage = physical_damage;
		this.desc = desc;
	}

	public abstract void attack(AbstractPlayer other, AbstractPlayer me);

	public int getPhysicalDamageVariation()
	{
		int variation_plus_minus = 5;
		return (int) (Math.random() * variation_plus_minus * 2) - variation_plus_minus + physical_damage;
	}

	public int getMentalDamageVariation()
	{
		int variation_plus_minus = 5;
		return (int) (Math.random() * variation_plus_minus * 2) - variation_plus_minus + mental_damage;
	}

	public String getDesc()
	{
		return desc;
	}

	public void setMentalDamage(int mentalDamage)
	{
		this.mental_damage = mentalDamage;
	}

	public void setPhysicalDamage(int physicalDamage)
	{
		this.physical_damage = physicalDamage;
	}
}

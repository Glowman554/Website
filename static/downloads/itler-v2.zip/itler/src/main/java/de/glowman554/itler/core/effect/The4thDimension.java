package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class The4thDimension extends AbstractEffect
{

	public The4thDimension(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return other.hasEffect(The4thDimension.class) != 0;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return other.hasEffect(The4thDimension.class) != 0;
	}

}

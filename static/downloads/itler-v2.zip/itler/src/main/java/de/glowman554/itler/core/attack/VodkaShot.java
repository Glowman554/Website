package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Drunk;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.renderfox.lazy.LazySound;

public class VodkaShot extends AbstractAttack
{
	private LazySound sound = new LazySound("sound/vodkapiva.mp3");


	public VodkaShot()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.russian.vodka_shot").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		sound.getSound().play();
		
		me.addEffect(new Drunk(2));
		other.addEffect(new Drunk(2));
	}
}

package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.Cocktail;
import de.glowman554.itler.core.attack.GayOuting;
import de.glowman554.itler.core.attack.GaySlap;
import de.glowman554.itler.core.attack.HentaiThrow;

public class Lena extends AbstractPlayer
{
	public Lena()
	{
		super(80, 40, new AbstractAttack[] {new GayOuting(), new GaySlap(), new Cocktail(), new HentaiThrow()});
	}
}

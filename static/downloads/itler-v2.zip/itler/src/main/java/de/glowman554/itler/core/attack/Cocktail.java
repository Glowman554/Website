package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Gay;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class Cocktail extends AbstractAttack
{
	public Cocktail()
	{
		super(10, 10, InGame.instance.getTranslation().get("attack.gay.cocktail").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new Gay(2));
		other.addEffect(new MentalConfusion(1));

		me.dealDamage(-getPhysicalDamageVariation(), me);
		me.dealMentalDamage(-getMentalDamageVariation(), me);
	}
}

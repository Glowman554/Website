package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.DivisionByZero;
import de.glowman554.itler.core.attack._4dDoge;
import de.glowman554.itler.core.attack._4dExplanation;
import de.glowman554.itler.core.attack._4dPunch;

public class Franz extends AbstractPlayer
{

	public Franz()
	{
		super(40, 80, new AbstractAttack[] {new _4dDoge(), new _4dPunch(), new _4dExplanation(), new DivisionByZero()});
	}

}

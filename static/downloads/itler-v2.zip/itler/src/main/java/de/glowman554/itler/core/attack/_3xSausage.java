package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Cheese;
import de.glowman554.itler.core.effect.Sausage;
import de.glowman554.itler.core.effect.SchwaebischGood;
import de.glowman554.itler.core.player.AbstractPlayer;

public class _3xSausage extends AbstractAttack
{
	public _3xSausage()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.food.3x_sausage").begin().end());

	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		if (me.hasEffect(Cheese.class) >= 2)
		{
			me.addEffect(new SchwaebischGood(1));
			me.addEffect(new Sausage(3));
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.food.cheese_needed").begin().replace("c", "2").end());
		}
	}
}

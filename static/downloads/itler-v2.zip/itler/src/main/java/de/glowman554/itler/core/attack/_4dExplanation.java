package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class _4dExplanation extends AbstractAttack
{
	public _4dExplanation()
	{
		super(0, 0, InGame.instance.getTranslation().get("attack.4d.explanation").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new MentalConfusion(3));
		other.addEffect(new MentalConfusion(3));
	}
}

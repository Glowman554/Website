package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.player.AbstractPlayer;

public class SchroedingersSyscall extends AbstractAttack
{
	public SchroedingersSyscall()
	{
		super(20, -20, InGame.instance.getTranslation().get("attack.os.schrödingers_syscall").begin().end());

	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{
		me.addEffect(new MentalConfusion(3));

		other.dealDamage(getMentalDamageVariation(), me);
		me.dealDamage(getMentalDamageVariation(), me);
		me.dealDamage(getPhysicalDamageVariation(), me);
	}
}

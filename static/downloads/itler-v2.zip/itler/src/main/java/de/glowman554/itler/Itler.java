package de.glowman554.itler;

import java.io.IOException;

import de.glowman554.renderfox.RenderFoxBuilder;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.plugins.PluginLoader;
import de.glowman554.renderfox.rendering.SplashScreen;

public class Itler
{
	public static void main(String[] args) throws IOException
	{
		PluginLoader.loadAll("plugins");

		int height = 640;
		int width = height * 2;

		new RenderFoxBuilder().targetFPS(60).size(width, height).title("ITLer").launch(new SplashScreen(new LazyTexture("splash.png"), new PreLaunch(), 1000));
	}

}

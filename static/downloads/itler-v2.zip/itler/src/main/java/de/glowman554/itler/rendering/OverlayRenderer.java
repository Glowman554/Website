package de.glowman554.itler.rendering;

import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.AbstractEffect;
import de.glowman554.itler.core.effect.Cheese;
import de.glowman554.itler.core.effect.Corruption;
import de.glowman554.itler.core.effect.Drunk;
import de.glowman554.itler.core.effect.EngineStalled;
import de.glowman554.itler.core.effect.Fat;
import de.glowman554.itler.core.effect.Full;
import de.glowman554.itler.core.effect.Furry;
import de.glowman554.itler.core.effect.Gay;
import de.glowman554.itler.core.effect.Horny;
import de.glowman554.itler.core.effect.Mass;
import de.glowman554.itler.core.effect.MentalConfusion;
import de.glowman554.itler.core.effect.Perfect;
import de.glowman554.itler.core.effect.Russian;
import de.glowman554.itler.core.effect.Sausage;
import de.glowman554.itler.core.effect.SchwaebischGood;
import de.glowman554.itler.core.effect.The4thDimension;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.renderfox.lazy.LazyTexture;
import de.glowman554.renderfox.rendering.RenderComponent;
import de.glowman554.renderfox.utils.Percent;

public class OverlayRenderer extends RenderComponent
{

	private AbstractPlayer player;

	private LazyTexture overlay;
	private LazyTexture bar;

	public static HashMap<Class<? extends AbstractEffect>, LazyTexture> textures = new HashMap<>();
	private static LazyTexture unknown = new LazyTexture("effects/unknown.png");

	static
	{
		textures.put(Cheese.class, new LazyTexture("effects/cheese.png"));
		textures.put(Corruption.class, new LazyTexture("effects/corruption.png"));
		textures.put(Full.class, new LazyTexture("effects/full.png"));
		textures.put(Furry.class, new LazyTexture("effects/furry.png"));
		textures.put(Gay.class, new LazyTexture("effects/gay.png"));
		textures.put(Horny.class, new LazyTexture("effects/horny.png"));
		textures.put(MentalConfusion.class, new LazyTexture("effects/mental_confusion.png"));
		textures.put(Perfect.class, new LazyTexture("effects/perfect.png"));
		textures.put(Sausage.class, new LazyTexture("effects/sausage.png"));
		textures.put(SchwaebischGood.class, new LazyTexture("effects/schwaebisch_good.png"));
		textures.put(The4thDimension.class, new LazyTexture("effects/4d.png"));
		textures.put(Mass.class, new LazyTexture("effects/mass.png"));
		textures.put(Fat.class, new LazyTexture("effects/fat.png"));
		textures.put(EngineStalled.class, new LazyTexture("effects/stalled_engine.png"));
		textures.put(Russian.class, new LazyTexture("effects/russian.png"));
		textures.put(Drunk.class, new LazyTexture("effects/drunk.png"));

	}

	public OverlayRenderer()
	{
		overlay = new LazyTexture("ui/overlay.png");
		bar = new LazyTexture("ui/bar.png");
	}

	@Override
	public void render(SpriteBatch batch, BitmapFont font)
	{
		batch.begin();
		batch.draw(overlay.getTexture(), 0, 0);

		font.setColor(Color.WHITE);
		font.draw(batch, player.getClass().getSimpleName(), 100 * 10, Gdx.graphics.getHeight() - 3 * 10 - 5);
		font.draw(batch, "HP", 103 * 10, Gdx.graphics.getHeight() - 9 * 10 - 5);
		font.draw(batch, "IG", 103 * 10, Gdx.graphics.getHeight() - 14 * 10 - 5);

		batch.draw(bar.getTexture(), 109 * 10, Gdx.graphics.getHeight() - 11 * 10, Percent.percent_of(17 * 10, (int) (((double) player.getHealth() / (double) player.getOrigHealth()) * 100.0)), 10);
		batch.draw(bar.getTexture(), 109 * 10, Gdx.graphics.getHeight() - 16 * 10, Percent.percent_of(17 * 10, (int) (((double) player.getIntelligence() / (double) player.getOrigIntelligence()) * 100.0)), 10);

		font.setColor(Color.BLUE);

		int current_line = 10;

		for (int i = 0; i < player.getAttacks().length; i++)
		{
			font.draw(batch, InGame.instance.getTranslation().get("ui.attack").begin().replace("c", String.valueOf(i + 1)).replace("d", player.getAttacks()[i].getDesc()).end(), 360, Gdx.graphics.getHeight() - ((font.getCapHeight() + 5) * current_line++));
		}

		for (int i = 0; i < player.getEffects().size(); i++)
		{
			LazyTexture t = textures.get(player.getEffects().get(i).getClass());
			if (t == null)
			{

				t = unknown;
			}

			batch.draw(t.getTexture(), 0, Gdx.graphics.getHeight() - 100 - ((t.getTexture().getHeight() + 10) * i));
			font.draw(batch, String.valueOf(player.getEffects().get(i).getLevel()), t.getTexture().getWidth() + 10, Gdx.graphics.getHeight() - 100 - ((t.getTexture().getHeight() + 10) * i) + (t.getTexture().getHeight() / 2 + font.getCapHeight() / 2));
		}

		batch.end();
	}

	public void setPlayer(AbstractPlayer player)
	{
		this.player = player;
	}
}

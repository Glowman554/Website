package de.glowman554.itler.core.effect;

import de.glowman554.itler.core.player.AbstractPlayer;

public class Drunk extends AbstractEffect
{

	public Drunk(int level)
	{
		super(level);
	}

	@Override
	public boolean allowMentalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return true;
	}

	@Override
	public boolean allowPhysicalDamage(AbstractPlayer other, AbstractPlayer me)
	{
		return false;
	}

}

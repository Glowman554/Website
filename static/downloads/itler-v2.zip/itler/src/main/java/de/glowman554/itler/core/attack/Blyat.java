package de.glowman554.itler.core.attack;

import de.glowman554.itler.InGame;
import de.glowman554.itler.core.effect.Drunk;
import de.glowman554.itler.core.effect.Russian;
import de.glowman554.itler.core.player.AbstractPlayer;
import de.glowman554.renderfox.lazy.LazySound;

public class Blyat extends AbstractAttack
{
	private LazySound sound = new LazySound("sound/blyat.mp3");

	public Blyat()
	{
		super(20, 20, InGame.instance.getTranslation().get("attack.russian.blyat").begin().end());
	}

	@Override
	public void attack(AbstractPlayer other, AbstractPlayer me)
	{

		if (me.hasEffect(Drunk.class) >= 1)
		{
			sound.getSound().play();
			
			me.addEffect(new Russian(2));

			other.dealDamage(getPhysicalDamageVariation(), me);
			other.dealMentalDamage(getMentalDamageVariation(), me);
		}
		else
		{
			throw new IllegalStateException(InGame.instance.getTranslation().get("attack.russian.not_drunk").begin().end());
		}

	}

}

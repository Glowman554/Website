package de.glowman554.itler.core.player;

import de.glowman554.itler.core.attack.AbstractAttack;
import de.glowman554.itler.core.attack.Bread;
import de.glowman554.itler.core.attack.CheesePlate;
import de.glowman554.itler.core.attack.Hospitality;
import de.glowman554.itler.core.attack._3xSausage;

public class Adrian extends AbstractPlayer
{
	public Adrian()
	{
		super(60, 60, new AbstractAttack[] {new CheesePlate(), new Hospitality(), new Bread(), new _3xSausage()});

	}
}

package gq.glowman554.password;

import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import gq.glowman554.password.utils.SHA256;

public class Crypto
{
	private char[] securekey;
	private char[] lesssecurekey;

	private int xors = 5;

	private String sha256(String data) throws NoSuchAlgorithmException
	{
		return SHA256.toHexString(SHA256.getSHA(data));
	}

	public Crypto(String password) throws NoSuchAlgorithmException
	{
		securekey = sha256(password).toCharArray();
		lesssecurekey = sha256(sha256(password)).toCharArray();

		System.out.println("secure: " + new String(securekey));
		System.out.println("lesssecure: " + new String(lesssecurekey));
	}

	private char[] encrypt(char[] input, char[] key)
	{
		char[] out = new char[input.length];
		for (int i = 0; i < input.length; i++)
		{
			out[i] = input[i];
			for (int j = 0; j < xors; j++)
			{
				out[i] ^= key[(i + j * xors) % key.length];
			}
		}

		return out;
	}

	private char[] decrypt(char[] input, char[] key)
	{
		char[] out = new char[input.length];
		for (int i = 0; i < input.length; i++)
		{
			out[i] = input[i];
			for (int j = xors - 1; j >= 0; j--)
			{
				out[i] ^= key[(i + j * xors) % key.length];
			}
		}

		return out;
	}

	public String base64(char[] input)
	{
		byte[] byteArray = new String(input).getBytes();
		return Base64.getEncoder().encodeToString(byteArray);
	}

	public char[] base64(String input)
	{
		byte[] byteArray = Base64.getDecoder().decode(input);
		String decodedString = new String(byteArray);
		return decodedString.toCharArray();
	}

	public char[] encryptSecure(char[] input)
	{
		return encrypt(input, securekey);
	}

	public char[] decryptSecure(char[] input)
	{
		return decrypt(input, securekey);
	}

	public char[] encryptLessSecure(char[] input)
	{
		return encrypt(input, lesssecurekey);
	}

	public char[] decryptLessSecure(char[] input)
	{
		return decrypt(input, lesssecurekey);
	}
}

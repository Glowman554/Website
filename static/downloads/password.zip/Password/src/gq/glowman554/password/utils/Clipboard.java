package gq.glowman554.password.utils;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;

public class Clipboard
{
	public static void copy(String value)
	{
		java.awt.datatransfer.Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();

		StringSelection selection = new StringSelection(value);
		clipboard.setContents(selection, null);
	}
}

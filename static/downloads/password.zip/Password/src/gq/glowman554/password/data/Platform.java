package gq.glowman554.password.data;

import java.util.ArrayList;

public class Platform
{
	private final String name;
	private final int id;
	private ArrayList<Key> keys = new ArrayList<>();

	public Platform(String name, int id)
	{
		this.name = name;
		this.id = id;
	}
	
	public String getName()
	{
		return name;
	}
	
	public int getId()
	{
		return id;
	}
	
	public Key[] getKeys()
	{
		return keys.toArray(new Key[0]);
	}
	
	public void addKey(Key key)
	{
		keys.add(key);
	}
}

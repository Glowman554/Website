package gq.glowman554.password.api;

import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import gq.glowman554.password.data.PwnedPassword;
import gq.glowman554.password.utils.SHA1;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class HaveIBeenPwned
{
	private static String request(String _url) throws IOException
	{
		URL url = new URL(_url);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();

		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
		con.setRequestProperty("Accept", "application/json");

		String response = "";

		for (byte b : con.getInputStream().readAllBytes())
		{
			response += (char) b;
		}

		con.getInputStream().close();
		con.disconnect();

		return response;
	}

	public static boolean isBad(String password) throws NoSuchAlgorithmException, IOException
	{
		String hash = SHA1.toHexString(SHA1.getSHA(password)).toUpperCase();
		String range = hash.substring(0, 5);
		String search = hash.substring(5);

		var res = Arrays.stream(request("https://api.pwnedpasswords.com/range/" + range).split("\\n")).map(v -> v.trim()).map(v -> {
			var split = v.split(":");
			return new PwnedPassword(split[0], Integer.parseInt(split[1]));
		}).filter(v -> v.getHash_part().equals(search)).toArray();

		return res.length > 0;
	}
}

package gq.glowman554.password.utils;

import java.security.SecureRandom;

public class PasswordGenerator
{
	// Generate a random password of a given length
	public static String generatePassword(int length)
	{
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?";
		char[] password = new char[length];
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[16];
		random.nextBytes(salt);
		for (int i = 0; i < length; i++)
		{
			password[i] = characters.charAt(Math.abs(random.nextInt()) % characters.length());
		}
		return new String(password);

	}
}
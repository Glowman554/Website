package gq.glowman554.password;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import gq.glowman554.password.api.HaveIBeenPwned;
import gq.glowman554.password.utils.SHA1;

public class TestMain
{
	private static String encryptSecure(String in, Crypto c)
	{
		return c.base64(c.encryptSecure(in.toCharArray()));
	}

	private static String decryptSecure(String in, Crypto c)
	{
		return new String(c.decryptSecure(c.base64(in)));
	}

	public static void main(String[] args) throws NoSuchAlgorithmException, IOException
	{
		Crypto c = new Crypto("password");

		String x = encryptSecure("Hello World!", c);

		System.out.println(c.base64(x));
		
		System.out.println(x);
		System.out.println(decryptSecure(x, c));
		
		System.out.println(SHA1.toHexString(SHA1.getSHA("hello")));
		System.out.println(HaveIBeenPwned.isBad("test"));
	}
}

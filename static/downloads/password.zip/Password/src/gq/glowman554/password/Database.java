package gq.glowman554.password;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import gq.glowman554.password.data.Key;
import gq.glowman554.password.data.Platform;

public class Database extends Thread
{
	private String db_path = "keychain";
	private Connection connect = null;
	private final Crypto crypto;

	public Database(Crypto crypto) throws IOException, SQLException
	{
		this.crypto = crypto;
		createIfNecesary();

		connect = DriverManager.getConnection(String.format("jdbc:sqlite:%s", db_path));

		Runtime.getRuntime().addShutdownHook(this);
	}

	@Override
	public void run()
	{
		System.out.println("Closing database.");
		try
		{
			connect.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}

	private String encryptSecure(String in)
	{
		return crypto.base64(crypto.encryptSecure(in.toCharArray()));
	}

	private String decryptSecure(String in)
	{
		return new String(crypto.decryptSecure(crypto.base64(in)));
	}

	private String encryptLessSecure(String in)
	{
		return crypto.base64(crypto.encryptLessSecure(in.toCharArray()));
	}

	private String decryptLessSecure(String in)
	{
		return new String(crypto.decryptLessSecure(crypto.base64(in)));
	}

	private void createIfNecesary() throws IOException
	{
		if (!new File(db_path).exists())
		{
			try (InputStream inputStream = Database.class.getResourceAsStream("/keychain"); OutputStream outputStream = new FileOutputStream(db_path))
			{

				byte[] buffer = new byte[1024];
				int length;
				while ((length = inputStream.read(buffer)) > 0)
				{
					outputStream.write(buffer, 0, length);
				}

				System.out.println("File copied successfully!");

			}
			catch (IOException e)
			{
				e.printStackTrace();
			}

			System.out.println("Wrote " + db_path + ".");
		}
	}

	public void createPlatform(String name) throws SQLException
	{
		PreparedStatement st = connect.prepareStatement("insert into platforms (name) values (?)");
		st.setString(1, name);
		st.execute();
		st.close();
	}

	public void insertKey(int pid, String username, String password) throws SQLException
	{
		PreparedStatement st = connect.prepareStatement("insert into keys (pid, username, password) values (?, ?, ?)");
		st.setInt(1, pid);
		st.setString(2, encryptLessSecure(username));
		st.setString(3, encryptSecure(password));
		st.execute();
		st.close();
	}

	public void deleteKey(int kid) throws SQLException
	{
		PreparedStatement st = connect.prepareStatement("delete from keys where id = ?");
		st.setInt(1, kid);
		st.execute();
		st.close();
	}

	public Platform[] load() throws SQLException
	{
		PreparedStatement st = connect.prepareStatement("select name, username, password, keys.pid, id from keys, platforms where keys.pid = platforms.pid");

		HashMap<String, Platform> platforms = new HashMap<>();

		ResultSet rs = st.executeQuery();
		while (rs.next())
		{
			if (platforms.get(rs.getString("name")) == null)
			{
				platforms.put(rs.getString("name"), new Platform(rs.getString("name"), rs.getInt("pid")));
			}
			platforms.get(rs.getString("name")).addKey(new Key(decryptLessSecure(rs.getString("username")), decryptSecure(rs.getString("password")), rs.getInt("id")));
		}

		rs.close();
		st.close();

		return platforms.values().toArray(new Platform[0]);
	}

	public int getPlatform(String name) throws SQLException
	{
		PreparedStatement st = connect.prepareStatement("select pid from platforms where name = ?");
		st.setString(1, name);
		ResultSet rs = st.executeQuery();

		if (!rs.next())
		{
			rs.close();
			st.close();
			return -1;
		}
		else
		{
			int ret = rs.getInt("pid");
			rs.close();
			st.close();
			return ret;
		}

	}
}

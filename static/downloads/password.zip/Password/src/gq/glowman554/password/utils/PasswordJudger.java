package gq.glowman554.password.utils;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

import gq.glowman554.password.api.HaveIBeenPwned;
import gq.glowman554.rockyou.RockYou;

public class PasswordJudger
{
	public static RockYou rockYou = new RockYou();

	public static String checkStrength(String password)
	{
		int score = 0; // initialize score to 0

		// Check length and add to score
		if (password.length() >= 8 && password.length() <= 12)
		{
			System.out.println("length: +1");
			score += 1;
		}
		else
			if (password.length() > 12)
			{
				System.out.println("length: +2");
				score += 2;
			}

		// Check complexity and add to score
		if (Pattern.compile("[a-z]").matcher(password).find())
		{
			System.out.println("a-z: +1");
			score += 1;
		}
		if (Pattern.compile("[A-Z]").matcher(password).find())
		{
			System.out.println("A-Z: +1");
			score += 1;
		}
		if (Pattern.compile("[0-9]").matcher(password).find())
		{
			System.out.println("0-9: +1");
			score += 1;
		}
		if (Pattern.compile("[!@#$%&()_+=|<>?{}\\[\\]~-]").matcher(password).find())
		{
			System.out.println("other: +1");
			score += 1;
		}

		try
		{
			if (rockYou.isBad(password))
			{
				System.out.println("rockyou: -1000");
				score -= 1000;
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		try
		{
			if (HaveIBeenPwned.isBad(password))
			{
				System.out.println("pwned: -1000");
				score -= 1000;
			}
		}
		catch (IOException | NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		
		// https://haveibeenpwned.com/API/v3#SearchingPwnedPasswordsByRange TODO implement

		System.out.println("score: " + score);
		
		String scores = " (" + score + ")";

		if (score < 0)
		{
			return "what da hail change your password idiot" + scores;
		}
		else
			if (score < 2)
			{
				return "weak" + scores;
			}
			else
				if (score < 5)
				{
					return "medium" + scores;
				}
				else
				{
					return "strong" + scores;
				}
	}
}

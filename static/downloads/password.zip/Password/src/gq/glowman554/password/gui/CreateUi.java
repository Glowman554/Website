package gq.glowman554.password.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import gq.glowman554.password.utils.PasswordGenerator;
import gq.glowman554.password.utils.PasswordJudger;

public class CreateUi extends JFrame
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextPane txtUsername;
	private JLabel lblNewLabel_2;
	private JTextPane txtPassword;
	private JTextPane txtPlatform;
	private JButton btnCreate;
	private JLabel lblStrength;
	private JButton btnNewButton;

	/**
	 * Create the frame.
	 * 
	 * @param actionListener
	 */
	public CreateUi(boolean random, MainUi mainui)
	{
		setTitle("Create");
		setResizable(false);
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 187);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		this.lblNewLabel = new JLabel("Username:");
		this.lblNewLabel.setBounds(10, 11, 63, 14);
		this.contentPane.add(this.lblNewLabel);

		this.lblNewLabel_1 = new JLabel("Password:");
		this.lblNewLabel_1.setBounds(10, 36, 63, 14);
		this.contentPane.add(this.lblNewLabel_1);

		this.txtUsername = new JTextPane();
		this.txtUsername.setBounds(83, 11, 341, 20);
		this.contentPane.add(this.txtUsername);

		this.lblNewLabel_2 = new JLabel("Platform:");
		this.lblNewLabel_2.setBounds(10, 61, 63, 14);
		this.contentPane.add(this.lblNewLabel_2);

		this.txtPassword = new JTextPane();
		this.txtPassword.setEditable(!random);
		this.txtPassword.setBounds(83, 36, 341, 20);
		this.contentPane.add(this.txtPassword);
		/*
		 * txtPassword.addKeyListener(new KeyListener() {
		 * 
		 * @Override public void keyTyped(KeyEvent e) { }
		 * 
		 * @Override public void keyReleased(KeyEvent e) {
		 * lblStrength.setText(PasswordJudger.checkStrength(txtPassword.getText(
		 * ))); }
		 * 
		 * @Override public void keyPressed(KeyEvent e) { } });
		 */

		this.txtPlatform = new JTextPane();
		this.txtPlatform.setBounds(83, 61, 341, 20);
		this.contentPane.add(this.txtPlatform);

		this.btnCreate = new JButton("Create");
		this.btnCreate.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					mainui.create(txtUsername.getText(), txtPassword.getText(), txtPlatform.getText());
				}
				catch (SQLException e1)
				{
					e1.printStackTrace();
				}
				dispose();
			}
		});
		this.btnCreate.setBounds(10, 115, 414, 23);
		this.contentPane.add(this.btnCreate);

		this.lblStrength = new JLabel("");
		this.lblStrength.setHorizontalAlignment(SwingConstants.CENTER);
		this.lblStrength.setBounds(83, 86, 341, 14);
		this.contentPane.add(this.lblStrength);

		this.btnNewButton = new JButton("Check");
		this.btnNewButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				lblStrength.setText(PasswordJudger.checkStrength(txtPassword.getText()));
			}
		});
		this.btnNewButton.setBounds(10, 86, 69, 23);
		this.contentPane.add(this.btnNewButton);

		if (random)
		{
			txtPassword.setText(PasswordGenerator.generatePassword(20));
		}
	}
}

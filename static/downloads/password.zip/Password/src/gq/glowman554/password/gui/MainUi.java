package gq.glowman554.password.gui;

import java.awt.EventQueue;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import gq.glowman554.password.Crypto;
import gq.glowman554.password.Database;
import gq.glowman554.password.data.Key;
import gq.glowman554.password.data.Platform;
import gq.glowman554.password.utils.Clipboard;

import javax.swing.JPasswordField;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainUi extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final Database database;
	private JTabbedPane tabbedPane;
	private JButton btnCreateRandom;
	private JButton btnInsert;
	private JButton btnDelete;

	private int ckid = -1;

	/**
	 * Launch the application.
	 * 
	 * @throws UnsupportedLookAndFeelException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException
	{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

		JPasswordField passwordField = new JPasswordField();
		Object[] inputFields = {"Password:", passwordField};
		JOptionPane.showConfirmDialog(null, inputFields, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		String password = new String(passwordField.getPassword());
		
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					MainUi frame = new MainUi(new Crypto(password));
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	private void printPlatforms(Platform[] platforms)
	{
		for (Platform p : platforms)
		{
			System.out.println("> " + p.getName() + "(" + p.getId() + ")");
			for (Key k : p.getKeys())
			{
				System.out.println("> > " + k.getUsername() + "(" + k.getId() + ")");
			}
		}
	}

	private void addPlatforms(Platform[] platforms)
	{
		printPlatforms(platforms);
		for (Platform p : platforms)
		{
			JScrollPane scrollPane = new JScrollPane();
			tabbedPane.addTab(p.getName(), null, scrollPane, null);

			JList<String> list = new JList<>();
			list.setModel(new AbstractListModel<String>()
			{
				private static final long serialVersionUID = 1L;
				private Key[] keys = p.getKeys();

				public int getSize()
				{
					return keys.length;
				}

				public String getElementAt(int index)
				{
					return keys[index].getUsername();
				}
			});
			list.addListSelectionListener(new ListSelectionListener()
			{

				@Override
				public void valueChanged(ListSelectionEvent e)
				{
					if (!e.getValueIsAdjusting())
					{
						String selectedValue = list.getSelectedValue();
						for (Key k : p.getKeys())
						{
							if (k.getUsername().equals(selectedValue))
							{
								p.getId();
								ckid = k.getId();

								System.out.println("Key: " + k.getId() + " " + k.getUsername());
								Clipboard.copy(k.getPassword());
							}
						}
					}
				}

			});

			scrollPane.setViewportView(list);
		}
	}

	private void update() throws SQLException
	{
		tabbedPane.removeAll();
		addPlatforms(database.load());
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	public MainUi(Crypto crypto) throws IOException, SQLException
	{
		setTitle("Password");
		this.database = new Database(crypto);
		// database.createPlatform("test2");
		// database.insertKey(2, "glowbruh", "test2");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 328);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		this.tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		this.tabbedPane.setBounds(10, 11, 414, 239);
		this.contentPane.add(this.tabbedPane);

		MainUi _this = this;

		this.btnCreateRandom = new JButton("Create random");
		this.btnCreateRandom.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				new CreateUi(true, _this).setVisible(true);
			}
		});
		this.btnCreateRandom.setBounds(10, 261, 141, 23);
		this.contentPane.add(this.btnCreateRandom);

		this.btnInsert = new JButton("Insert");
		this.btnInsert.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				new CreateUi(false, _this).setVisible(true);
			}
		});
		this.btnInsert.setBounds(161, 261, 89, 23);
		this.contentPane.add(this.btnInsert);

		this.btnDelete = new JButton("Delete");
		this.btnDelete.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					database.deleteKey(ckid);
					update();
				}
				catch (SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		});
		this.btnDelete.setBounds(335, 261, 89, 23);
		this.contentPane.add(this.btnDelete);

		update();
	}

	private int findPlatform(String platform) throws SQLException
	{
		int ret = database.getPlatform(platform);
		if (ret == -1)
		{
			database.createPlatform(platform);
			ret = database.getPlatform(platform);
		}
		return ret;
	}

	public void create(String username, String password, String platform) throws SQLException
	{
		database.insertKey(findPlatform(platform), username, password);
		update();
	}
}

package gq.glowman554.password.data;

public class PwnedPassword
{
	private final String hash_part;
	private final int ammount;

	public PwnedPassword(String hash_part, int ammount)
	{
		this.hash_part = hash_part;
		this.ammount = ammount;

	}

	public int getAmmount()
	{
		return ammount;
	}

	public String getHash_part()
	{
		return hash_part;
	}
}

package gq.glowman554.password.data;

public class Key
{
	private final String username;
	private final String password;
	private final int id;

	public Key(String username, String password, int id)
	{
		this.username = username;
		this.password = password;
		this.id = id;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public String getUsername()
	{
		return username;
	}
	
	public int getId()
	{
		return id;
	}
}
